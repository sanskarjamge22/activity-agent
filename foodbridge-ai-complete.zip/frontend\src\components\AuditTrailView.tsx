import React, { useState } from 'react';
import { 
  FileCheck, 
  ShieldCheck, 
  AlertTriangle, 
  RefreshCw, 
  Hash, 
  User, 
  Clock, 
  Search 
} from 'lucide-react';
import { AuditLogEntry } from '../types';

interface AuditTrailViewProps {
  logs: AuditLogEntry[];
  onVerifyIntegrity: () => Promise<any>;
  onRefresh: () => Promise<void>;
  isVerifying: boolean;
}

export const AuditTrailView: React.FC<AuditTrailViewProps> = ({
  logs,
  onVerifyIntegrity,
  onRefresh,
  isVerifying
}) => {
  const [filterWorkflow, setFilterWorkflow] = useState('');
  const [verificationResult, setVerificationResult] = useState<{
    valid: boolean;
    total_entries_verified: number;
    latest_head_hash: string;
  } | null>(null);

  const handleVerify = async () => {
    const res = await onVerifyIntegrity();
    setVerificationResult(res);
  };

  const filteredLogs = filterWorkflow
    ? logs.filter((l) => l.workflow_id.toLowerCase().includes(filterWorkflow.toLowerCase()))
    : logs;

  return (
    <div>
      {/* Header */}
      <div className="glass-panel" style={{ padding: '1.75rem', marginBottom: '1.5rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem' }}>
              <span className="badge badge-success">Tamper-Evident Ledger</span>
              <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Cryptographic Chaining</span>
            </div>
            <h2 style={{ fontSize: '1.45rem', fontWeight: 800, color: '#f8fafc' }}>
              Sequential Audit & Compliance Trail
            </h2>
            <p style={{ fontSize: '0.85rem', color: '#cbd5e1' }}>
              Every AI planning step, tool call, human approval decision, and mathematical verification is cryptographically linked with SHA-256 HMAC hashes.
            </p>
          </div>

          <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
            <button
              className="btn-secondary"
              onClick={onRefresh}
              title="Refresh logs"
            >
              <RefreshCw size={16} />
              <span>Refresh</span>
            </button>
            <button
              className="btn-primary"
              onClick={handleVerify}
              disabled={isVerifying}
            >
              <ShieldCheck size={18} />
              <span>{isVerifying ? 'Verifying Hashes...' : 'Verify Chain Integrity'}</span>
            </button>
          </div>
        </div>

        {/* Verification Result Banner */}
        {verificationResult && (
          <div style={{
            marginTop: '1.25rem',
            padding: '1rem 1.25rem',
            borderRadius: '0.75rem',
            background: verificationResult.valid ? 'rgba(16, 185, 129, 0.15)' : 'rgba(244, 63, 94, 0.15)',
            border: verificationResult.valid ? '1px solid rgba(16, 185, 129, 0.3)' : '1px solid rgba(244, 63, 94, 0.3)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: '1rem'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              {verificationResult.valid ? (
                <ShieldCheck size={24} color="#34d399" />
              ) : (
                <AlertTriangle size={24} color="#fb7185" />
              )}
              <div>
                <h4 style={{ fontSize: '0.95rem', fontWeight: 700, color: verificationResult.valid ? '#34d399' : '#fb7185' }}>
                  {verificationResult.valid ? '✓ Cryptographic Chain Fully Valid' : 'Tamper Detected in Audit Chain'}
                </h4>
                <p style={{ fontSize: '0.75rem', color: '#cbd5e1' }}>
                  Walked from Genesis block across {verificationResult.total_entries_verified} sequential events. 0 invalid pointers or corrupted signatures.
                </p>
              </div>
            </div>
            <div style={{ fontSize: '0.7rem', fontFamily: 'monospace', color: '#94a3b8' }}>
              Head: {verificationResult.latest_head_hash.slice(0, 16)}...{verificationResult.latest_head_hash.slice(-8)}
            </div>
          </div>
        )}
      </div>

      {/* Filter Bar */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1.25rem' }}>
        <div style={{ position: 'relative', flex: 1, maxWidth: '350px' }}>
          <Search size={16} color="#94a3b8" style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)' }} />
          <input
            type="text"
            placeholder="Filter by workflow ID..."
            value={filterWorkflow}
            onChange={(e) => setFilterWorkflow(e.target.value)}
            style={{
              width: '100%',
              padding: '0.55rem 0.75rem 0.55rem 2.25rem',
              borderRadius: '0.65rem',
              background: 'rgba(0, 0, 0, 0.3)',
              border: '1px solid var(--border-color)',
              color: '#ffffff',
              fontSize: '0.8rem'
            }}
          />
        </div>
        <span style={{ fontSize: '0.8rem', color: '#94a3b8' }}>
          Showing {filteredLogs.length} events
        </span>
      </div>

      {/* Audit Log Table */}
      <div className="glass-panel" style={{ overflowX: 'auto', padding: '0.5rem' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.8rem' }}>
          <thead>
            <tr style={{ borderBottom: '1px solid var(--border-color)', color: '#94a3b8' }}>
              <th style={{ padding: '0.75rem 1rem' }}>Timestamp</th>
              <th style={{ padding: '0.75rem 1rem' }}>Workflow ID</th>
              <th style={{ padding: '0.75rem 1rem' }}>Event Type</th>
              <th style={{ padding: '0.75rem 1rem' }}>Actor</th>
              <th style={{ padding: '0.75rem 1rem' }}>Details Summary</th>
              <th style={{ padding: '0.75rem 1rem' }}>SHA-256 HMAC</th>
            </tr>
          </thead>
          <tbody>
            {filteredLogs.slice(-40).reverse().map((entry) => (
              <tr 
                key={entry.entry_id}
                style={{ borderBottom: '1px solid rgba(255, 255, 255, 0.04)', transition: 'background 0.15s' }}
                onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(255, 255, 255, 0.03)'}
                onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
              >
                <td style={{ padding: '0.75rem 1rem', whiteSpace: 'nowrap', color: '#94a3b8', fontFamily: 'monospace' }}>
                  {new Date(entry.timestamp).toLocaleTimeString()}
                </td>
                <td style={{ padding: '0.75rem 1rem', whiteSpace: 'nowrap', fontFamily: 'monospace', color: '#38bdf8' }}>
                  {entry.workflow_id}
                </td>
                <td style={{ padding: '0.75rem 1rem', whiteSpace: 'nowrap' }}>
                  <span className={`badge ${
                    entry.event_type.includes('SUCCESS') || entry.event_type.includes('COMPLETED') ? 'badge-success' :
                    entry.event_type.includes('APPROVAL') ? 'badge-warning' :
                    entry.event_type.includes('FAIL') ? 'badge-danger' : 'badge-info'
                  }`} style={{ fontSize: '0.65rem' }}>
                    {entry.event_type}
                  </span>
                </td>
                <td style={{ padding: '0.75rem 1rem', whiteSpace: 'nowrap', color: '#cbd5e1' }}>
                  {entry.actor}
                </td>
                <td style={{ padding: '0.75rem 1rem', maxWidth: '300px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: '#cbd5e1' }}>
                  {JSON.stringify(entry.details)}
                </td>
                <td style={{ padding: '0.75rem 1rem', whiteSpace: 'nowrap', fontFamily: 'monospace', fontSize: '0.7rem', color: '#94a3b8' }}>
                  {entry.current_hash.slice(0, 10)}...{entry.current_hash.slice(-6)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
