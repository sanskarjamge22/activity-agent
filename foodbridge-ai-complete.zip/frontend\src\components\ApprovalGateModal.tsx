import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Check, 
  X, 
  AlertTriangle, 
  Lock, 
  DollarSign, 
  Building2, 
  UserCheck 
} from 'lucide-react';
import { PlanStep, UserRole } from '../types';

interface ApprovalGateModalProps {
  step: PlanStep | null;
  workflowId: string;
  userRole: UserRole;
  onDecision: (decision: 'APPROVE' | 'REJECT', decidedBy: string, reason: string) => Promise<void>;
  onClose: () => void;
  isSubmitting: boolean;
}

export const ApprovalGateModal: React.FC<ApprovalGateModalProps> = ({
  step,
  workflowId,
  userRole,
  onDecision,
  onClose,
  isSubmitting
}) => {
  if (!step) return null;

  const defaultDecider = userRole === 'canteen_staff' 
    ? 'Chef Marcus (Canteen Lead)' 
    : userRole === 'dispatcher'
    ? 'Dispatcher Jane (Logistics Ops)'
    : 'System Supervisor';

  const [decidedBy, setDecidedBy] = useState(defaultDecider);
  const [reason, setReason] = useState('Authorized by logistics supervisor after verifying transport capacity and partner readiness.');

  const handleApprove = async () => {
    await onDecision('APPROVE', decidedBy, reason);
  };

  const handleReject = async () => {
    await onDecision('REJECT', decidedBy, reason || 'Action rejected by supervisor.');
  };

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'rgba(0, 0, 0, 0.75)',
      backdropFilter: 'blur(8px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1000,
      padding: '1rem'
    }}>
      <div className="glass-panel" style={{
        maxWidth: '650px',
        width: '100%',
        padding: '2rem',
        background: '#0f172a',
        border: '1px solid rgba(245, 158, 11, 0.5)',
        boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.8)'
      }}>
        
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <div style={{ padding: '0.6rem', borderRadius: '0.75rem', background: 'rgba(245, 158, 11, 0.2)', color: '#fbbf24' }}>
              <ShieldAlert size={28} />
            </div>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <span className="badge badge-warning">Human Approval Gate</span>
                <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Workflow: {workflowId}</span>
              </div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: '#f8fafc' }}>
                {step.title}
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            style={{ background: 'transparent', border: 'none', color: '#94a3b8', cursor: 'pointer', padding: '0.5rem' }}
          >
            <X size={20} />
          </button>
        </div>

        {/* Warning Callout */}
        <div style={{ background: 'rgba(245, 158, 11, 0.08)', border: '1px solid rgba(245, 158, 11, 0.25)', borderRadius: '0.75rem', padding: '1rem', marginBottom: '1.25rem' }}>
          <p style={{ fontSize: '0.85rem', color: '#fbbf24', lineHeight: '1.5' }}>
            <strong>Consequential Action Policy:</strong> This operation involves external commitments (carrier freight contract, legal custody manifest, or direct community alert). Autonomous execution is halted until explicitly authorized.
          </p>
        </div>

        {/* Action Details & Arguments */}
        <div style={{ marginBottom: '1.25rem' }}>
          <h4 style={{ fontSize: '0.85rem', fontWeight: 700, color: '#cbd5e1', marginBottom: '0.5rem' }}>
            Tool Arguments & Payload Inspection:
          </h4>
          <div style={{ background: 'rgba(0, 0, 0, 0.4)', borderRadius: '0.5rem', padding: '0.75rem 1rem', border: '1px solid var(--border-color)', fontFamily: 'monospace', fontSize: '0.75rem', color: '#38bdf8', maxHeight: '140px', overflowY: 'auto' }}>
            <pre style={{ whiteSpace: 'pre-wrap' }}>
              {JSON.stringify(step.tool_arguments, null, 2)}
            </pre>
          </div>
        </div>

        {/* Form Inputs: Authorized By & Reason */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem', marginBottom: '1.25rem' }}>
          <div>
            <label style={{ display: 'block', fontSize: '0.75rem', fontWeight: 600, color: '#94a3b8', marginBottom: '0.35rem' }}>
              Authorized Sign-off Name *
            </label>
            <input
              type="text"
              required
              value={decidedBy}
              onChange={(e) => setDecidedBy(e.target.value)}
              style={{
                width: '100%',
                padding: '0.55rem 0.75rem',
                borderRadius: '0.5rem',
                background: 'rgba(0, 0, 0, 0.3)',
                border: '1px solid var(--border-color)',
                color: '#ffffff',
                fontSize: '0.825rem'
              }}
            />
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '0.75rem', fontWeight: 600, color: '#94a3b8', marginBottom: '0.35rem' }}>
              Approval / Rejection Rationale *
            </label>
            <input
              type="text"
              required
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              style={{
                width: '100%',
                padding: '0.55rem 0.75rem',
                borderRadius: '0.5rem',
                background: 'rgba(0, 0, 0, 0.3)',
                border: '1px solid var(--border-color)',
                color: '#ffffff',
                fontSize: '0.825rem'
              }}
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '0.75rem', paddingTop: '1rem', borderTop: '1px solid var(--border-color)' }}>
          <button
            type="button"
            className="btn-danger"
            onClick={handleReject}
            disabled={isSubmitting}
          >
            <X size={16} />
            <span>Reject & Cancel Workflow</span>
          </button>
          
          <button
            type="button"
            className="btn-primary"
            onClick={handleApprove}
            disabled={isSubmitting}
          >
            <Check size={16} />
            <span>{isSubmitting ? 'Authorizing...' : 'Authorize & Execute'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
