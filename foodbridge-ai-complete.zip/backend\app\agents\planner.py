import json
import uuid
import httpx
from typing import Dict, Any, List
from app.config import settings
from app.models.schemas import ActionPlan, PlanStep, ToolSensitivity, StepStatus
from app.tools.registry import tool_registry

class PlannerAgent:
    def __init__(self):
        self.api_key = settings.GEMINI_API_KEY
        self.model = settings.GEMINI_MODEL

    async def generate_plan(
        self,
        incident_id: str,
        objective: str,
        warehouse_id: str,
        inventory_batch_id: str,
        max_budget_usd: float,
        max_transit_hours: float,
        require_refrigeration: bool
    ) -> ActionPlan:
        """Generates a structured, dependency-aware plan using Gemini API or high-fidelity deterministic engine."""
        
        # If API key is available, call Gemini API
        if self.api_key and not settings.DEMO_MODE:
            try:
                return await self._call_gemini_api(
                    incident_id=incident_id,
                    objective=objective,
                    warehouse_id=warehouse_id,
                    inventory_batch_id=inventory_batch_id,
                    max_budget_usd=max_budget_usd,
                    max_transit_hours=max_transit_hours,
                    require_refrigeration=require_refrigeration
                )
            except Exception as e:
                # Log error and fall back gracefully to deterministic plan
                print(f"[PlannerAgent] Gemini API call failed or timed out: {e}. Falling back to deterministic planner.")

        # Deterministic engine (Hackathon compliant: high-fidelity, auditable, safe)
        return self._build_deterministic_plan(
            incident_id=incident_id,
            objective=objective,
            warehouse_id=warehouse_id,
            inventory_batch_id=inventory_batch_id,
            max_budget_usd=max_budget_usd,
            max_transit_hours=max_transit_hours
        )

    async def _call_gemini_api(
        self,
        incident_id: str,
        objective: str,
        warehouse_id: str,
        inventory_batch_id: str,
        max_budget_usd: float,
        max_transit_hours: float,
        require_refrigeration: bool
    ) -> ActionPlan:
        """Invokes Google Gemini REST endpoint with strict JSON schema instructions."""
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent?key={self.api_key}"
        
        available_tools = list(tool_registry.get_allowlist())
        system_instruction = (
            "You are the Lead Logistics & Risk Planner for ActiVity AI. "
            "Your job is to analyze food rescue incidents and produce an ordered sequence of executable tool steps. "
            "You MUST select tools ONLY from this allowlist: " + ", ".join(available_tools) + ". "
            "Mark sensitive steps like booking freight and dispatching manifests as SENSITIVE_REQUIRES_APPROVAL. "
            "Return valid JSON matching the specified schema."
        )

        user_prompt = f"""
Objective: {objective}
Warehouse: {warehouse_id}
Batch: {inventory_batch_id}
Budget Limit: ${max_budget_usd}
Max Transit Hours: {max_transit_hours}
Refrigeration Required: {require_refrigeration}

Provide a JSON object with:
- summary_rationale (string)
- root_cause_analysis (string)
- estimated_cost_usd (float)
- estimated_food_saved_kg (float)
- estimated_co2_averted_kg (float)
- steps: array of steps with (step_id, step_order, title, description, tool_name, tool_arguments, sensitivity, dependencies, expected_outcome, verification_rule)
"""

        payload = {
            "contents": [
                {
                    "role": "user",
                    "parts": [{"text": system_instruction + "\n\n" + user_prompt}]
                }
            ],
            "generationConfig": {
                "temperature": 0.2,
                "response_mime_type": "application/json"
            }
        }

        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(url, json=payload)
            resp.raise_for_status()
            data = resp.json()
            raw_text = data["candidates"][0]["content"]["parts"][0]["text"]
            parsed = json.loads(raw_text)

            steps = []
            for s in parsed.get("steps", []):
                steps.append(PlanStep(
                    step_id=s.get("step_id", f"step-{uuid.uuid4().hex[:6]}"),
                    step_order=s.get("step_order", len(steps) + 1),
                    title=s.get("title", "Execute Step"),
                    description=s.get("description", ""),
                    tool_name=s.get("tool_name", "inspect_inventory_telemetry"),
                    tool_arguments=s.get("tool_arguments", {}),
                    sensitivity=ToolSensitivity(s.get("sensitivity", "SAFE_AUTONOMOUS")),
                    dependencies=s.get("dependencies", []),
                    expected_outcome=s.get("expected_outcome", "Tool executed successfully"),
                    verification_rule=s.get("verification_rule", "status == 'SUCCESS'"),
                    approval_required=(s.get("sensitivity") == ToolSensitivity.SENSITIVE_REQUIRES_APPROVAL.value)
                ))

            return ActionPlan(
                plan_id=f"plan-{uuid.uuid4().hex[:8]}",
                incident_id=incident_id,
                summary_rationale=parsed.get("summary_rationale", "Autonomous redistribution plan constructed."),
                root_cause_analysis=parsed.get("root_cause_analysis", "Perishable batch approaching critical expiry threshold."),
                estimated_cost_usd=float(parsed.get("estimated_cost_usd", 175.0)),
                estimated_food_saved_kg=float(parsed.get("estimated_food_saved_kg", 1420.0)),
                estimated_co2_averted_kg=float(parsed.get("estimated_co2_averted_kg", 3976.0)),
                steps=steps
            )

    def _build_deterministic_plan(
        self,
        incident_id: str,
        objective: str,
        warehouse_id: str,
        inventory_batch_id: str,
        max_budget_usd: float,
        max_transit_hours: float
    ) -> ActionPlan:
        """Deterministic plan builder guaranteeing rock-solid end-to-end execution and safety."""
        plan_id = f"plan-{uuid.uuid4().hex[:8]}"

        steps = [
            PlanStep(
                step_id="step-1-inspect",
                step_order=1,
                title="Telemetry & Perishability Audit",
                description=f"Query IoT thermal sensor array and inventory shelf life for batch '{inventory_batch_id}' at '{warehouse_id}'.",
                tool_name="inspect_inventory_telemetry",
                tool_arguments={"warehouse_id": warehouse_id, "batch_id": inventory_batch_id},
                sensitivity=ToolSensitivity.SAFE_AUTONOMOUS,
                status=StepStatus.PLANNED,
                dependencies=[],
                expected_outcome="Telemetry confirmation of batch viability, exact kg, and safe temperature history.",
                verification_rule="temperature_within_safe_limits == true and hours_until_spoilage > 0",
                approval_required=False
            ),
            PlanStep(
                step_id="step-2-match",
                step_order=2,
                title="Identify Verified Community Recipient",
                description="Query food bank network for certified partners within geographic radius with matching refrigeration capacity.",
                tool_name="match_recipient_network",
                tool_arguments={"commodity_category": "Perishable Dairy", "required_capacity_kg": 1420.0, "max_distance_km": 45.0},
                sensitivity=ToolSensitivity.SAFE_AUTONOMOUS,
                status=StepStatus.PLANNED,
                dependencies=["step-1-inspect"],
                expected_outcome="Identified top-matched partner with capacity and active cold storage.",
                verification_rule="total_matched_recipients > 0 and selected_best_recipient.compliance_verified == true",
                approval_required=False
            ),
            PlanStep(
                step_id="step-3-reserve-freight",
                step_order=3,
                title="Contract Reefer Transport (Gate Action)",
                description="Reserve commercial refrigerated vehicle 'EverFrost CleanFleet' within budget limits.",
                tool_name="reserve_cold_freight",
                tool_arguments={
                    "carrier_id": "CARRIER-COLD-90",
                    "pickup_location": warehouse_id,
                    "delivery_location": "RECIP-EASTBAY-01",
                    "weight_kg": 1420.0
                },
                sensitivity=ToolSensitivity.SENSITIVE_REQUIRES_APPROVAL,
                status=StepStatus.AWAITING_APPROVAL,
                dependencies=["step-2-match"],
                expected_outcome="Confirmed vehicle reservation, assigned certified driver, and generated booking ref.",
                verification_rule="status == 'BOOKED' and total_cost_usd <= max_budget",
                approval_required=True
            ),
            PlanStep(
                step_id="step-4-dispatch-manifest",
                step_order=4,
                title="Issue Bill of Lading & Dispatch (Gate Action)",
                description="Execute legal transfer manifest, decrement warehouse ledger, and issue live barcode tracking.",
                tool_name="dispatch_transfer_manifest",
                tool_arguments={
                    "batch_id": inventory_batch_id,
                    "recipient_id": "RECIP-EASTBAY-01",
                    "carrier_id": "CARRIER-COLD-90",
                    "booking_ref": "BK-FRG-PENDING"
                },
                sensitivity=ToolSensitivity.SENSITIVE_REQUIRES_APPROVAL,
                status=StepStatus.AWAITING_APPROVAL,
                dependencies=["step-3-reserve-freight"],
                expected_outcome="Authorized transfer manifest issued, tracking active, custody state IN_TRANSIT.",
                verification_rule="status == 'DISPATCHED' and manifest_id != null",
                approval_required=True
            ),
            PlanStep(
                step_id="step-5-verify-coldchain",
                step_order=5,
                title="Post-Transit Cold-Chain Verification",
                description="Analyze transit temperature datalogger to mathematically verify no temperature excursions occurred.",
                tool_name="verify_temperature_integrity",
                tool_arguments={"manifest_id": "MNF-PENDING", "min_temp_c": 1.0, "max_temp_c": 4.5},
                sensitivity=ToolSensitivity.SAFE_AUTONOMOUS,
                status=StepStatus.PLANNED,
                dependencies=["step-4-dispatch-manifest"],
                expected_outcome="HACCP food safety compliance mathematically verified.",
                verification_rule="cold_chain_breach == false and haccp_compliant == true",
                approval_required=False
            ),
            PlanStep(
                step_id="step-6-finalize-custody",
                step_order=6,
                title="Recipient Handover & Digital Receipt",
                description="Capture electronic signature from recipient food bank, closing chain-of-custody.",
                tool_name="finalize_chain_of_custody",
                tool_arguments={"manifest_id": "MNF-PENDING", "recipient_id": "RECIP-EASTBAY-01"},
                sensitivity=ToolSensitivity.SAFE_AUTONOMOUS,
                status=StepStatus.PLANNED,
                dependencies=["step-5-verify-coldchain"],
                expected_outcome="Cryptographic delivery receipt recorded and custody closed.",
                verification_rule="chain_of_custody_closed == true",
                approval_required=False
            ),
            PlanStep(
                step_id="step-7-impact-accounting",
                step_order=7,
                title="Quantified Environmental & Social Accounting",
                description="Calculate verified kg rescued, meals provided, CO2e averted, and economic value preserved.",
                tool_name="calculate_impact_accounting",
                tool_arguments={"batch_id": inventory_batch_id, "rescued_kg": 1420.0},
                sensitivity=ToolSensitivity.SAFE_AUTONOMOUS,
                status=StepStatus.PLANNED,
                dependencies=["step-6-finalize-custody"],
                expected_outcome="Auditable impact ledger entry created.",
                verification_rule="food_rescued_kg > 0 and co2e_averted_kg > 0",
                approval_required=False
            )
        ]

        return ActionPlan(
            plan_id=plan_id,
            incident_id=incident_id,
            summary_rationale=f"High-priority rescue plan for {inventory_batch_id}: cold-chain transit to certified partner Alameda County Community Food Bank before spoilage threshold.",
            root_cause_analysis="Distribution demand delay identified 36-hour remaining shelf-life on 1,420 kg perishable dairy requiring emergency redistribution under HACCP rules.",
            estimated_cost_usd=175.0,
            estimated_food_saved_kg=1420.0,
            estimated_co2_averted_kg=3976.0,
            steps=steps
        )

planner_agent = PlannerAgent()
