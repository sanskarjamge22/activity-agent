import os
from pydantic import BaseModel

class Settings(BaseModel):
    APP_NAME: str = "FoodBridge AI"
    APP_TITLE: str = "FoodBridge AI — Smart Food Waste Rescue Agent"
    APP_VERSION: str = "1.0.0"
    APP_ENV: str = os.getenv("APP_ENV", "development")
    HOST: str = os.getenv("HOST", "0.0.0.0")
    PORT: int = int(os.getenv("PORT", "8000"))
    
    # AI Engine Configuration
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", os.getenv("GOOGLE_API_KEY", ""))
    GEMINI_MODEL: str = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    DEMO_MODE: bool = os.getenv("DEMO_MODE", "true").lower() in ("true", "1", "yes") if not os.getenv("GEMINI_API_KEY") else False
    
    # Security & Policy Settings
    SECRET_KEY: str = os.getenv("SECRET_KEY", "activity-ai-hackathon-secure-master-key-2026")
    AUDIT_SALT: str = os.getenv("AUDIT_SALT", "tamper-evident-audit-salt-activity-ai")
    ENABLE_PROMPT_INJECTION_DEFENSE: bool = True
    MAX_WORKFLOW_RETRIES: int = 3
    TOOL_TIMEOUT_SECONDS: int = 15
    MAX_ALLOWABLE_BUDGET_USD: float = 2500.00
    
    # Allowed CORS Origins
    CORS_ORIGINS: list[str] = [
        "http://localhost:5173",
        "http://localhost:3000",
        "http://127.0.0.1:5173",
        "http://127.0.0.1:3000",
        "*"
    ]

settings = Settings()
