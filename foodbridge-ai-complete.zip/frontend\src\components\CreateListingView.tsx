import React, { useState } from 'react';
import { 
  Utensils, 
  Sparkles, 
  ShieldCheck, 
  Clock, 
  MapPin, 
  AlertCircle, 
  Check, 
  Building2, 
  Send
} from 'lucide-react';
import { DonorProfile, UserRole } from '../types';

interface CreateListingViewProps {
  donors: DonorProfile[];
  onSubmit: (formData: any) => Promise<void>;
  userRole: UserRole;
  isSubmitting: boolean;
}

export const CreateListingView: React.FC<CreateListingViewProps> = ({
  donors,
  onSubmit,
  userRole,
  isSubmitting
}) => {
  const PRESETS = [
    {
      title: "North Campus Dinner Surplus - Mediterranean Bowls",
      description: "85 portions of warm turmeric rice, roasted halal chicken, and grilled seasonal vegetables. Prepared at 18:00, held at safe warm holding temp.",
      warehouse_id: "CANTEEN-CAMPUS-NORTH",
      donor_name: "North Campus Student Dining Hall",
      donor_type: "COLLEGE_CANTEEN",
      food_category: "PREPARED_HOT_MEALS",
      estimated_servings: 85,
      weight_kg: 42.5,
      safe_consumption_window_hours: 4.0,
      dietary_tags: ["Halal", "Vegetarian Options"],
      pickup_address: "North Campus Commons, Berkeley, CA",
      max_budget_usd: 50.0,
      max_transit_hours: 1.5,
      require_refrigeration: false
    },
    {
      title: "Golden Crust Evening Bakery Surplus",
      description: "140 freshly baked sourdough batards, seeded whole-grain boules, and pain au chocolat from day end closing.",
      warehouse_id: "REST-ARTISAN-BAKERY",
      donor_name: "Golden Crust Artisan Bakery & Cafe",
      donor_type: "BAKERY",
      food_category: "FRESH_BAKERY",
      estimated_servings: 140,
      weight_kg: 55.0,
      safe_consumption_window_hours: 24.0,
      dietary_tags: ["Vegetarian"],
      pickup_address: "2100 University Ave, Berkeley, CA",
      max_budget_usd: 35.0,
      max_transit_hours: 3.0,
      require_refrigeration: false
    },
    {
      title: "Engineering Quad Pre-packaged Salads & Sandwiches",
      description: "65 individually boxed organic quinoa salads and artisan roast vegetable paninis from midday cafe excess.",
      warehouse_id: "CANTEEN-ENG-QUAD",
      donor_name: "Engineering Quad Dining Hub",
      donor_type: "COLLEGE_CANTEEN",
      food_category: "FRESH_PRODUCE",
      estimated_servings: 65,
      weight_kg: 32.0,
      safe_consumption_window_hours: 6.0,
      dietary_tags: ["Vegan", "Nut-Free"],
      pickup_address: "Hearst Memorial Mining Plaza, CA",
      max_budget_usd: 40.0,
      max_transit_hours: 2.0,
      require_refrigeration: true
    }
  ];

  const [form, setForm] = useState(PRESETS[0]);
  const [error, setError] = useState<string | null>(null);

  const applyPreset = (preset: typeof PRESETS[0]) => {
    setForm(preset);
    setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await onSubmit({
        ...form,
        inventory_batch_id: `BATCH-${Date.now().toString().slice(-6)}`
      });
    } catch (err: any) {
      setError(err.message || 'Failed to submit surplus listing');
    }
  };

  // Client-side prompt injection check for immediate feedback
  const containsSuspiciousText = 
    /ignore.*instructions|developer.*mode|bypass.*guidelines|reveal.*key/i.test(form.description);

  return (
    <div style={{ maxWidth: '900px', margin: '0 auto' }}>
      
      {/* Header */}
      <div className="glass-panel" style={{ padding: '1.5rem', marginBottom: '1.5rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem' }}>
              <span className="badge badge-success">Food Surplus Creator</span>
              <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Restaurants • Dining Halls • Canteens</span>
            </div>
            <h2 style={{ fontSize: '1.45rem', fontWeight: 800, color: '#f8fafc' }}>
              Create Surplus Food Rescue Listing
            </h2>
            <p style={{ fontSize: '0.85rem', color: '#cbd5e1' }}>
              Submit surplus inventory. FoodBridge AI will immediately analyze food safety, match local NGOs, and build an auditable rescue plan.
            </p>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <span className="badge badge-cyan">
              <ShieldCheck size={14} /> Sanitization Active
            </span>
          </div>
        </div>
      </div>

      {/* Preset Quick Selectors */}
      <div style={{ marginBottom: '1.5rem' }}>
        <label style={{ fontSize: '0.8rem', fontWeight: 600, color: '#94a3b8', display: 'block', marginBottom: '0.5rem' }}>
          ✨ Quick Presets for Restaurants & College Canteens:
        </label>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '0.75rem' }}>
          {PRESETS.map((p, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => applyPreset(p)}
              className="glass-panel glass-panel-hover"
              style={{
                textAlign: 'left',
                padding: '0.85rem 1rem',
                cursor: 'pointer',
                border: form.title === p.title ? '1px solid #10b981' : undefined,
                background: form.title === p.title ? 'rgba(16, 185, 129, 0.12)' : undefined
              }}
            >
              <div style={{ fontWeight: 700, fontSize: '0.85rem', color: '#f8fafc', marginBottom: '0.25rem' }}>
                {p.title.split(' - ')[0]}
              </div>
              <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>
                {p.estimated_servings} servings • {p.donor_name}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="glass-panel" style={{ padding: '1.75rem' }}>
        
        {error && (
          <div style={{ padding: '1rem', background: 'rgba(244, 63, 94, 0.15)', border: '1px solid rgba(244, 63, 94, 0.3)', borderRadius: '0.75rem', color: '#fb7185', fontSize: '0.85rem', marginBottom: '1.25rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <AlertCircle size={18} />
            <span>{error}</span>
          </div>
        )}

        {containsSuspiciousText && (
          <div style={{ padding: '0.75rem 1rem', background: 'rgba(245, 158, 11, 0.15)', border: '1px solid rgba(245, 158, 11, 0.3)', borderRadius: '0.75rem', color: '#fbbf24', fontSize: '0.8rem', marginBottom: '1.25rem' }}>
            ⚠️ Notice: Prompt injection or instruction override patterns are detected. The security firewall will block or sanitize this input upon submission.
          </div>
        )}

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.25rem', marginBottom: '1.25rem' }}>
          
          {/* Title */}
          <div>
            <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, color: '#cbd5e1', marginBottom: '0.35rem' }}>
              Listing Title *
            </label>
            <input
              type="text"
              required
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              style={{
                width: '100%',
                padding: '0.65rem 0.85rem',
                borderRadius: '0.65rem',
                background: 'rgba(0, 0, 0, 0.3)',
                border: '1px solid var(--border-color)',
                color: '#ffffff',
                fontSize: '0.875rem'
              }}
            />
          </div>

          {/* Donor Selection */}
          <div>
            <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, color: '#cbd5e1', marginBottom: '0.35rem' }}>
              Donor Facility (Canteen / Restaurant)
            </label>
            <select
              value={form.warehouse_id}
              onChange={(e) => {
                const found = donors.find((d) => d.donor_id === e.target.value);
                setForm({
                  ...form,
                  warehouse_id: e.target.value,
                  donor_name: found ? found.name : form.donor_name,
                  donor_type: found ? found.type : form.donor_type,
                  pickup_address: found ? found.location : form.pickup_address
                });
              }}
              style={{
                width: '100%',
                padding: '0.65rem 0.85rem',
                borderRadius: '0.65rem',
                background: 'rgba(15, 23, 42, 0.8)',
                border: '1px solid var(--border-color)',
                color: '#ffffff',
                fontSize: '0.875rem'
              }}
            >
              {donors.map((d) => (
                <option key={d.donor_id} value={d.donor_id}>
                  {d.name} ({d.type.replace('_', ' ')})
                </option>
              ))}
            </select>
          </div>

          {/* Category */}
          <div>
            <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, color: '#cbd5e1', marginBottom: '0.35rem' }}>
              Food Category
            </label>
            <select
              value={form.food_category}
              onChange={(e) => setForm({ ...form, food_category: e.target.value })}
              style={{
                width: '100%',
                padding: '0.65rem 0.85rem',
                borderRadius: '0.65rem',
                background: 'rgba(15, 23, 42, 0.8)',
                border: '1px solid var(--border-color)',
                color: '#ffffff',
                fontSize: '0.875rem'
              }}
            >
              <option value="PREPARED_HOT_MEALS">🍲 Prepared Hot Meals (Trays / Portions)</option>
              <option value="FRESH_BAKERY">🥖 Fresh Bakery & Pastries</option>
              <option value="CHILLED_DAIRY">🥛 Chilled Dairy & Beverages</option>
              <option value="FRESH_PRODUCE">🥗 Fresh Salads & Cut Produce</option>
              <option value="PACKAGED_GOODS">📦 Sealed / Packaged Foods</option>
            </select>
          </div>

          {/* Servings */}
          <div>
            <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, color: '#cbd5e1', marginBottom: '0.35rem' }}>
              Estimated Servings / Meals *
            </label>
            <input
              type="number"
              min="1"
              max="5000"
              required
              value={form.estimated_servings}
              onChange={(e) => setForm({ ...form, estimated_servings: parseInt(e.target.value) || 1 })}
              style={{
                width: '100%',
                padding: '0.65rem 0.85rem',
                borderRadius: '0.65rem',
                background: 'rgba(0, 0, 0, 0.3)',
                border: '1px solid var(--border-color)',
                color: '#ffffff',
                fontSize: '0.875rem'
              }}
            />
          </div>

          {/* Weight */}
          <div>
            <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, color: '#cbd5e1', marginBottom: '0.35rem' }}>
              Total Weight (kg)
            </label>
            <input
              type="number"
              step="0.5"
              min="0.5"
              value={form.weight_kg}
              onChange={(e) => setForm({ ...form, weight_kg: parseFloat(e.target.value) || 1.0 })}
              style={{
                width: '100%',
                padding: '0.65rem 0.85rem',
                borderRadius: '0.65rem',
                background: 'rgba(0, 0, 0, 0.3)',
                border: '1px solid var(--border-color)',
                color: '#ffffff',
                fontSize: '0.875rem'
              }}
            />
          </div>

          {/* Safe Window */}
          <div>
            <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, color: '#cbd5e1', marginBottom: '0.35rem' }}>
              Safe Consumption Window (Hours) *
            </label>
            <input
              type="number"
              step="0.5"
              min="0.5"
              max="72"
              value={form.safe_consumption_window_hours}
              onChange={(e) => setForm({ ...form, safe_consumption_window_hours: parseFloat(e.target.value) || 2.0 })}
              style={{
                width: '100%',
                padding: '0.65rem 0.85rem',
                borderRadius: '0.65rem',
                background: 'rgba(0, 0, 0, 0.3)',
                border: '1px solid var(--border-color)',
                color: '#ffffff',
                fontSize: '0.875rem'
              }}
            />
          </div>

        </div>

        {/* Description & Preparation Notes */}
        <div style={{ marginBottom: '1.25rem' }}>
          <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, color: '#cbd5e1', marginBottom: '0.35rem' }}>
            Description, Ingredients & Food Safety Notes *
          </label>
          <textarea
            required
            rows={3}
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            placeholder="Detailed description of prepared items, packaging, refrigeration, allergens..."
            style={{
              width: '100%',
              padding: '0.65rem 0.85rem',
              borderRadius: '0.65rem',
              background: 'rgba(0, 0, 0, 0.3)',
              border: '1px solid var(--border-color)',
              color: '#ffffff',
              fontSize: '0.875rem',
              fontFamily: 'inherit'
            }}
          />
        </div>

        {/* Refrigeration Checkbox & Submit */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem', paddingTop: '1rem', borderTop: '1px solid var(--border-color)' }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer', fontSize: '0.85rem', color: '#cbd5e1' }}>
            <input
              type="checkbox"
              checked={form.require_refrigeration}
              onChange={(e) => setForm({ ...form, require_refrigeration: e.target.checked })}
              style={{ accentColor: '#10b981', width: '16px', height: '16px' }}
            />
            <span>Requires active temperature-controlled transport (Reefer van)</span>
          </label>

          <button
            type="submit"
            className="btn-primary"
            disabled={isSubmitting}
            style={{ minWidth: '220px' }}
          >
            <Send size={18} />
            <span>{isSubmitting ? 'AI Reasoning & Planning...' : 'Publish & Engage Agent'}</span>
          </button>
        </div>

      </form>
    </div>
  );
};
