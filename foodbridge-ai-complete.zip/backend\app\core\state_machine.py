import uuid
from datetime import datetime
from typing import Dict, Any, Optional
from app.models.schemas import (
    WorkflowExecution,
    WorkflowStatus,
    StepStatus,
    ToolSensitivity,
    CreateIncidentRequest
)
from app.models.database import db
from app.core.audit import audit_manager
from app.agents.analyst import analyst_agent
from app.agents.planner import planner_agent
from app.agents.decision import decision_agent
from app.agents.verifier import verifier_agent
from app.tools.registry import tool_registry

class WorkflowStateMachine:
    async def create_and_plan_workflow(
        self,
        request: CreateIncidentRequest,
        actor: str = "DISPATCHER_USER"
    ) -> WorkflowExecution:
        """Initializes incident, analyzes data, and builds structured plan."""
        workflow_id = f"wf-{uuid.uuid4().hex[:8]}"
        incident_id = f"inc-{uuid.uuid4().hex[:8]}"
        
        # Save listing to persistent SQLite database
        listing_payload = request.model_dump()
        listing_payload["listing_id"] = incident_id
        db.save_listing(listing_payload)

        # Step 1: Data Analysis Agent
        analysis = analyst_agent.analyze_incident(
            warehouse_id=request.warehouse_id,
            inventory_batch_id=request.inventory_batch_id,
            max_transit_hours=request.max_transit_hours
        )

        audit_manager.log_event(
            workflow_id=workflow_id,
            event_type="INCIDENT_INGESTED",
            actor=actor,
            details={"incident_id": incident_id, "title": request.title, "analysis": analysis}
        )

        # Step 2: Planner Agent
        plan = await planner_agent.generate_plan(
            incident_id=incident_id,
            objective=request.description,
            warehouse_id=request.warehouse_id,
            inventory_batch_id=request.inventory_batch_id,
            max_budget_usd=request.max_budget_usd,
            max_transit_hours=request.max_transit_hours,
            require_refrigeration=request.require_refrigeration
        )

        audit_manager.log_event(
            workflow_id=workflow_id,
            event_type="PLAN_GENERATED",
            actor="AI_PLANNER_AGENT",
            details={
                "plan_id": plan.plan_id,
                "total_steps": len(plan.steps),
                "estimated_cost_usd": plan.estimated_cost_usd,
                "food_saved_kg": plan.estimated_food_saved_kg
            }
        )

        workflow = WorkflowExecution(
            workflow_id=workflow_id,
            incident_id=incident_id,
            title=request.title,
            status=WorkflowStatus.EXECUTING,
            current_step_index=0,
            total_steps=len(plan.steps),
            plan=plan,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )

        db.save_workflow(workflow)
        return workflow

    async def advance_workflow(self, workflow_id: str) -> WorkflowExecution:
        """Runs the next executable step or pauses at Human Approval Gate."""
        wf = db.get_workflow(workflow_id)
        if not wf or not wf.plan:
            raise ValueError(f"Workflow '{workflow_id}' not found.")

        if wf.status in (WorkflowStatus.COMPLETED, WorkflowStatus.FAILED, WorkflowStatus.CANCELLED):
            return wf

        if wf.current_step_index >= len(wf.plan.steps):
            wf.status = WorkflowStatus.COMPLETED
            wf.completed_at = datetime.utcnow()
            audit_manager.log_event(
                workflow_id=workflow_id,
                event_type="WORKFLOW_COMPLETED",
                actor="AI_AGENT",
                details={"completed_steps": wf.total_steps, "status": "ALL_VERIFICATIONS_PASSED"}
            )
            db.save_workflow(wf)
            return wf

        current_step = wf.plan.steps[wf.current_step_index]

        # Check Human Approval Gate
        if current_step.approval_required and current_step.status != StepStatus.APPROVED:
            wf.status = WorkflowStatus.AWAITING_APPROVAL
            current_step.status = StepStatus.AWAITING_APPROVAL
            audit_manager.log_event(
                workflow_id=workflow_id,
                event_type="APPROVAL_REQUIRED",
                actor="DECISION_GATE",
                details={
                    "step_id": current_step.step_id,
                    "tool": current_step.tool_name,
                    "reason": "Consequential operation requires logistics supervisor sign-off."
                }
            )
            db.save_workflow(wf)
            return wf

        # Execute Authorized Step
        wf.status = WorkflowStatus.EXECUTING
        current_step.status = StepStatus.RUNNING
        current_step.started_at = datetime.utcnow()

        audit_manager.log_event(
            workflow_id=workflow_id,
            event_type="TOOL_EXECUTION_STARTING",
            actor="TOOL_LAYER",
            details={"step_id": current_step.step_id, "tool": current_step.tool_name}
        )

        # Execute tool
        call_record = tool_registry.execute_tool(
            tool_name=current_step.tool_name,
            arguments=current_step.tool_arguments
        )

        # Verification step
        verification = verifier_agent.verify_step_execution(
            tool_name=current_step.tool_name,
            tool_output=call_record.output or {},
            verification_rule=current_step.verification_rule
        )

        current_step.completed_at = datetime.utcnow()
        current_step.actual_outcome = str(call_record.output)
        current_step.verification_passed = verification["passed"]

        if verification["passed"] and call_record.status == StepStatus.SUCCEEDED:
            current_step.status = StepStatus.SUCCEEDED
            audit_manager.log_event(
                workflow_id=workflow_id,
                event_type="STEP_VERIFIED_SUCCESS",
                actor="VERIFIER_AGENT",
                details={
                    "step_id": current_step.step_id,
                    "tool": current_step.tool_name,
                    "diagnostic": verification["reason"]
                }
            )
            # Propagate output data forward to dependent steps (e.g. booking_ref & manifest_id)
            self._propagate_step_outputs(wf, current_step.step_id, call_record.output or {})
            wf.current_step_index += 1
            if wf.current_step_index >= len(wf.plan.steps):
                wf.status = WorkflowStatus.COMPLETED
                wf.completed_at = datetime.utcnow()
        else:
            # Failure detected -> Safe Recovery Mode
            current_step.status = StepStatus.FAILED
            wf.retry_count += 1
            audit_manager.log_event(
                workflow_id=workflow_id,
                event_type="STEP_VERIFICATION_FAILED",
                actor="VERIFIER_AGENT",
                details={
                    "step_id": current_step.step_id,
                    "error": call_record.error_message or verification["reason"],
                    "retry_attempt": wf.retry_count
                }
            )

            if wf.retry_count < 3:
                wf.status = WorkflowStatus.RECOVERY
                # Safe fallback: retry with adjusted parameters
                current_step.status = StepStatus.PLANNED
            else:
                wf.status = WorkflowStatus.FAILED
                wf.error_message = f"Max retries exceeded on step {current_step.title}: {verification['reason']}"

        wf.updated_at = datetime.utcnow()
        db.save_workflow(wf)
        return wf

    def process_approval_decision(
        self,
        workflow_id: str,
        step_id: str,
        decision: str,
        decided_by: str,
        reason: Optional[str]
    ) -> WorkflowExecution:
        """Applies human approval or rejection to the gated step."""
        wf = db.get_workflow(workflow_id)
        if not wf or not wf.plan:
            raise ValueError(f"Workflow '{workflow_id}' not found.")

        step = next((s for s in wf.plan.steps if s.step_id == step_id), None)
        if not step:
            raise ValueError(f"Step '{step_id}' not found in workflow plan.")

        if decision == "APPROVE":
            step.status = StepStatus.APPROVED
            step.approved_by = decided_by
            wf.status = WorkflowStatus.EXECUTING
            audit_manager.log_event(
                workflow_id=workflow_id,
                event_type="APPROVAL_GRANTED",
                actor=decided_by,
                details={"step_id": step_id, "tool": step.tool_name, "reason": reason}
            )
        else:
            step.status = StepStatus.REJECTED
            step.rejection_reason = reason
            wf.status = WorkflowStatus.CANCELLED
            wf.error_message = f"Consequential step rejected by {decided_by}: {reason}"
            audit_manager.log_event(
                workflow_id=workflow_id,
                event_type="APPROVAL_REJECTED",
                actor=decided_by,
                details={"step_id": step_id, "tool": step.tool_name, "reason": reason}
            )

        wf.updated_at = datetime.utcnow()
        db.save_workflow(wf)
        return wf

    def _propagate_step_outputs(self, wf: WorkflowExecution, completed_step_id: str, output: Dict[str, Any]):
        """Injects outputs from upstream steps into downstream arguments."""
        if completed_step_id == "step-3-reserve-freight":
            ref = output.get("booking_reference")
            if ref and len(wf.plan.steps) > 3:
                wf.plan.steps[3].tool_arguments["booking_ref"] = ref

        elif completed_step_id == "step-4-dispatch-manifest":
            mnf_id = output.get("manifest_id")
            if mnf_id:
                if len(wf.plan.steps) > 4:
                    wf.plan.steps[4].tool_arguments["manifest_id"] = mnf_id
                if len(wf.plan.steps) > 5:
                    wf.plan.steps[5].tool_arguments["manifest_id"] = mnf_id

state_machine = WorkflowStateMachine()
