export type UserRole = 'canteen_staff' | 'dispatcher' | 'auditor' | 'admin';

export type WorkflowStatus = 
  | 'PENDING_ANALYSIS'
  | 'PLANNING'
  | 'AWAITING_APPROVAL'
  | 'EXECUTING'
  | 'VERIFYING'
  | 'COMPLETED'
  | 'FAILED'
  | 'CANCELLED'
  | 'RECOVERY';

export type StepStatus =
  | 'PLANNED'
  | 'AWAITING_APPROVAL'
  | 'APPROVED'
  | 'REJECTED'
  | 'RUNNING'
  | 'SUCCEEDED'
  | 'FAILED'
  | 'SKIPPED';

export type ToolSensitivity = 'SAFE_AUTONOMOUS' | 'SENSITIVE_REQUIRES_APPROVAL';

export interface PlanStep {
  step_id: string;
  step_order: number;
  title: string;
  description: string;
  tool_name: string;
  tool_arguments: Record<string, any>;
  sensitivity: ToolSensitivity;
  status: StepStatus;
  dependencies: string[];
  expected_outcome: string;
  actual_outcome?: string;
  verification_rule: string;
  verification_passed?: boolean;
  started_at?: string;
  completed_at?: string;
  approval_required: boolean;
  approved_by?: string;
  rejection_reason?: string;
}

export interface ActionPlan {
  plan_id: string;
  incident_id: string;
  summary_rationale: string;
  root_cause_analysis: string;
  estimated_cost_usd: number;
  estimated_food_saved_kg: number;
  estimated_co2_averted_kg: number;
  steps: PlanStep[];
  created_at: string;
}

export interface WorkflowExecution {
  workflow_id: string;
  incident_id: string;
  title: string;
  status: WorkflowStatus;
  current_step_index: number;
  total_steps: number;
  plan?: ActionPlan;
  audit_chain_hash?: string;
  created_at: string;
  updated_at: string;
  completed_at?: string;
  error_message?: string;
  retry_count: number;
  estimated_time_saved_minutes: number;
}

export interface SystemMetrics {
  total_workflows: number;
  completed_workflows: number;
  success_rate_percent: number;
  total_food_saved_kg: number;
  total_co2_averted_kg: number;
  total_cost_saved_usd: number;
  total_manual_hours_saved: number;
  median_latency_seconds: number;
  p95_latency_seconds: number;
  human_approval_rate_percent: number;
  failure_recovery_rate_percent: number;
}

export interface AuditLogEntry {
  entry_id: string;
  workflow_id: string;
  timestamp: string;
  event_type: string;
  actor: string;
  details: Record<string, any>;
  prev_hash: string;
  current_hash: string;
}

export interface RecipientNGO {
  recipient_id: string;
  name: string;
  address: string;
  distance_km: number;
  transit_time_minutes: number;
  accepts_categories: string[];
  cold_storage_capacity_kg: number;
  current_available_capacity_kg: number;
  refrigeration_guaranteed: boolean;
  contact_phone: string;
  compliance_verified: boolean;
  coordinator_name?: string;
}

export interface DonorProfile {
  donor_id: string;
  name: string;
  type: string;
  location: string;
  contact_person: string;
  contact_phone: string;
  operating_hours: string;
  refrigeration_available: boolean;
}
