from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

class UserRole(str, Enum):
    ADMIN = "admin"
    DISPATCHER = "dispatcher"
    AUDITOR = "auditor"
    CANTEEN_STAFF = "canteen_staff"

class DonorType(str, Enum):
    COLLEGE_CANTEEN = "COLLEGE_CANTEEN"
    RESTAURANT = "RESTAURANT"
    CAMPUS_DINING = "CAMPUS_DINING"
    BAKERY = "BAKERY"

class FoodCategory(str, Enum):
    PREPARED_HOT_MEALS = "PREPARED_HOT_MEALS"
    FRESH_BAKERY = "FRESH_BAKERY"
    CHILLED_DAIRY = "CHILLED_DAIRY"
    FRESH_PRODUCE = "FRESH_PRODUCE"
    PACKAGED_GOODS = "PACKAGED_GOODS"

class WorkflowStatus(str, Enum):
    PENDING_ANALYSIS = "PENDING_ANALYSIS"
    PLANNING = "PLANNING"
    AWAITING_APPROVAL = "AWAITING_APPROVAL"
    EXECUTING = "EXECUTING"
    VERIFYING = "VERIFYING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"
    RECOVERY = "RECOVERY"

class StepStatus(str, Enum):
    PLANNED = "PLANNED"
    AWAITING_APPROVAL = "AWAITING_APPROVAL"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    RUNNING = "RUNNING"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"

class ToolSensitivity(str, Enum):
    SAFE_AUTONOMOUS = "SAFE_AUTONOMOUS"
    SENSITIVE_REQUIRES_APPROVAL = "SENSITIVE_REQUIRES_APPROVAL"

# Input Schemas
class CreateIncidentRequest(BaseModel):
    title: str = Field(..., min_length=3, max_length=150)
    description: str = Field(..., min_length=10, max_length=2000)
    warehouse_id: Optional[str] = Field(default="WH-WEST-01", max_length=100)
    inventory_batch_id: Optional[str] = Field(default="BATCH-DAIRY-802", max_length=100)
    # Restaurant / Canteen specific fields
    donor_name: Optional[str] = Field(default="North Campus Student Dining Hall", max_length=150)
    donor_type: Optional[DonorType] = DonorType.COLLEGE_CANTEEN
    food_category: Optional[FoodCategory] = FoodCategory.PREPARED_HOT_MEALS
    estimated_servings: Optional[int] = Field(default=85, ge=1, le=5000)
    weight_kg: Optional[float] = Field(default=45.0, ge=0.5, le=5000.0)
    safe_consumption_window_hours: Optional[float] = Field(default=4.0, ge=0.5, le=72.0)
    dietary_tags: Optional[List[str]] = Field(default_factory=lambda: ["Vegetarian", "Halal Friendly"])
    pickup_address: Optional[str] = Field(default="Student Union Bldg, Level 1 Loading Bay", max_length=200)
    max_budget_usd: float = Field(default=50.0, ge=0.0, le=5000.0)
    max_transit_hours: float = Field(default=2.0, ge=0.5, le=24.0)
    require_refrigeration: bool = False
    notes: Optional[str] = Field(default="", max_length=1000)

class ApprovalDecisionRequest(BaseModel):
    step_id: str
    decision: str = Field(..., pattern="^(APPROVE|REJECT)$")
    decided_by: str = Field(..., min_length=2)
    reason: Optional[str] = Field(default="Authorized by logistics supervisor")

class UpdateListingStatusRequest(BaseModel):
    status: str = Field(..., pattern="^(AVAILABLE|RESERVED|PICKED_UP|CANCELLED)$")
    notes: Optional[str] = Field(default=None, max_length=500)

class MatchRecipientRequest(BaseModel):
    food_category: str = "PREPARED_HOT_MEALS"
    servings: int = 50
    weight_kg: float = 25.0
    max_distance_km: float = 25.0
    require_refrigeration: bool = False

class TemperatureValidationRequest(BaseModel):
    food_category: str
    temperature_c: float
    holding_duration_hours: float = 1.0

class ImpactCalculationRequest(BaseModel):
    food_category: str
    weight_kg: float

# Tool Invocation
class ToolCallRecord(BaseModel):
    tool_name: str
    arguments: Dict[str, Any]
    output: Optional[Dict[str, Any]] = None
    execution_time_ms: float = 0.0
    status: StepStatus = StepStatus.PLANNED
    error_message: Optional[str] = None

# Step & Plan Models
class PlanStep(BaseModel):
    step_id: str
    step_order: int
    title: str
    description: str
    tool_name: str
    tool_arguments: Dict[str, Any] = Field(default_factory=dict)
    sensitivity: ToolSensitivity = ToolSensitivity.SAFE_AUTONOMOUS
    status: StepStatus = StepStatus.PLANNED
    dependencies: List[str] = Field(default_factory=list)
    expected_outcome: str
    actual_outcome: Optional[str] = None
    verification_rule: str
    verification_passed: Optional[bool] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    approval_required: bool = False
    approved_by: Optional[str] = None
    rejection_reason: Optional[str] = None

class ActionPlan(BaseModel):
    plan_id: str
    incident_id: str
    summary_rationale: str
    root_cause_analysis: str
    estimated_cost_usd: float
    estimated_food_saved_kg: float
    estimated_co2_averted_kg: float
    steps: List[PlanStep]
    created_at: datetime = Field(default_factory=datetime.utcnow)

class WorkflowExecution(BaseModel):
    workflow_id: str
    incident_id: str
    title: str
    status: WorkflowStatus = WorkflowStatus.PENDING_ANALYSIS
    current_step_index: int = 0
    total_steps: int = 0
    plan: Optional[ActionPlan] = None
    audit_chain_hash: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    error_message: Optional[str] = None
    retry_count: int = 0
    estimated_time_saved_minutes: float = 45.0  # Baseline manual redistribution time

# Audit Log Entry
class AuditLogEntry(BaseModel):
    entry_id: str
    workflow_id: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    event_type: str  # PLAN_GENERATED, TOOL_EXECUTED, APPROVAL_REQUESTED, APPROVAL_GRANTED, VERIFICATION_PASSED, RECOVERY_TRIGGERED
    actor: str       # "AI_AGENT", "DISPATCHER_USER", "SYSTEM"
    details: Dict[str, Any]
    prev_hash: str
    current_hash: str

# Analytics & KPIs
class SystemMetrics(BaseModel):
    total_workflows: int
    completed_workflows: int
    success_rate_percent: float
    total_food_saved_kg: float
    total_co2_averted_kg: float
    total_cost_saved_usd: float
    total_manual_hours_saved: float
    median_latency_seconds: float
    p95_latency_seconds: float
    human_approval_rate_percent: float
    failure_recovery_rate_percent: float

# Settings Schema
class SecuritySettingsDTO(BaseModel):
    prompt_injection_defense: bool
    autonomous_safe_tools: bool
    max_budget_limit: float
    allowed_tools_count: int
    active_role: UserRole
    demo_mode: bool
