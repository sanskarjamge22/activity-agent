import re
import hashlib
import hmac
import time
from typing import Dict, Any, Optional, Set
from fastapi import HTTPException, Header, Depends, status
from app.config import settings
from app.models.schemas import UserRole

# Set of forbidden prompt injection signatures
PROMPT_INJECTION_PATTERNS = [
    r"ignore\s+(all\s+)?(previous|prior)\s+instructions",
    r"disregard\s+(the\s+)?above",
    r"you\s+are\s+now\s+in\s+developer\s+mode",
    r"bypass\s+safety\s+guidelines",
    r"override\s+system\s+prompt",
    r"act\s+as\s+an\s+unrestricted",
    r"do\s+anything\s+now",
    r"reveal\s+(api\s+key|secret|system\s+instructions)",
    r"drop\s+table",
    r"rm\s+-rf",
    r"<\s*script\s*>",
]

# Track processed idempotency keys with expiration timestamp
IDEMPOTENCY_STORE: Dict[str, float] = {}
IDEMPOTENCY_TTL_SECONDS = 300  # 5 minutes

class SecurityManager:
    @staticmethod
    def sanitize_text(text: str) -> str:
        """Sanitizes user text and protects against prompt injection override attempts."""
        if not text:
            return ""
        
        # Strip dangerous HTML / Script tags
        sanitized = re.sub(r"<[^>]*?>", "", text)
        
        # Check against injection patterns if enabled
        if settings.ENABLE_PROMPT_INJECTION_DEFENSE:
            for pattern in PROMPT_INJECTION_PATTERNS:
                if re.search(pattern, sanitized, re.IGNORECASE):
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Security Policy Violation: Malicious prompt injection pattern detected in input."
                    )
        
        # Escape common delimiter collision characters
        sanitized = sanitized.replace("```", "'''")
        return sanitized.strip()

    @staticmethod
    def check_idempotency(idempotency_key: Optional[str]) -> None:
        """Ensures duplicate requests with identical idempotency keys are prevented."""
        if not idempotency_key:
            return
            
        now = time.time()
        # Clean expired keys
        expired = [k for k, exp in IDEMPOTENCY_STORE.items() if exp < now]
        for k in expired:
            IDEMPOTENCY_STORE.pop(k, None)
            
        if idempotency_key in IDEMPOTENCY_STORE:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Idempotent action collision: Request with key '{idempotency_key}' already processed or in progress."
            )
        
        IDEMPOTENCY_STORE[idempotency_key] = now + IDEMPOTENCY_TTL_SECONDS

    @staticmethod
    def compute_audit_hash(prev_hash: str, payload: str) -> str:
        """Creates a tamper-evident SHA-256 HMAC for sequential audit logging."""
        message = f"{prev_hash}::{payload}".encode("utf-8")
        secret = settings.AUDIT_SALT.encode("utf-8")
        return hmac.new(secret, message, hashlib.sha256).hexdigest()

    @staticmethod
    def verify_tool_allowed(tool_name: str, allowlist: Set[str]) -> None:
        """Enforces tool execution allowlist."""
        if tool_name not in allowlist:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Tool Execution Blocked: '{tool_name}' is not in the authorized tool allowlist."
            )

def get_current_user(
    x_user_role: str = Header(default="dispatcher", alias="X-User-Role"),
    x_user_id: str = Header(default="usr-dispatch-01", alias="X-User-Id")
) -> Dict[str, Any]:
    """Extracts simulated authenticated user from secure headers with validation."""
    valid_roles = [r.value for r in UserRole]
    clean_role = x_user_role.lower()
    if clean_role not in valid_roles:
        clean_role = UserRole.DISPATCHER.value

    return {
        "user_id": x_user_id,
        "role": UserRole(clean_role)
    }

def require_role(allowed_roles: list[UserRole]):
    """FastAPI dependency for role-based access control."""
    def role_checker(user: Dict[str, Any] = Depends(get_current_user)):
        if user["role"] not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Access Denied: Requires one of {[r.value for r in allowed_roles]}, current role is '{user['role'].value}'."
            )
        return user
    return role_checker
