from typing import Dict, Any, List
from app.config import settings
from app.models.schemas import ToolSensitivity

class DecisionAgent:
    def evaluate_action_safety(
        self,
        tool_name: str,
        arguments: Dict[str, Any],
        max_budget_usd: float
    ) -> Dict[str, Any]:
        """Evaluates constraints and safety boundaries before allowing execution."""
        violations: List[str] = []
        requires_human_approval = False
        
        # Budget check
        if "total_cost_usd" in arguments:
            cost = float(arguments["total_cost_usd"])
            if cost > max_budget_usd:
                violations.append(f"Proposed cost ${cost} exceeds budget cap ${max_budget_usd}")
            if cost > settings.MAX_ALLOWABLE_BUDGET_USD:
                violations.append(f"Proposed cost ${cost} exceeds absolute system ceiling ${settings.MAX_ALLOWABLE_BUDGET_USD}")

        # Sensitivity check: Consequential and external actions requiring human sign-off
        sensitive_tools = [
            "reserve_cold_freight",
            "dispatch_transfer_manifest",
            "notify_ngo_coordinator",
            "confirm_donation_reservation"
        ]
        if tool_name in sensitive_tools:
            requires_human_approval = True

        return {
            "permitted": len(violations) == 0,
            "requires_human_approval": requires_human_approval,
            "violations": violations,
            "decision": "HOLD_FOR_APPROVAL" if requires_human_approval else ("PROCEED" if not violations else "BLOCKED")
        }

decision_agent = DecisionAgent()
