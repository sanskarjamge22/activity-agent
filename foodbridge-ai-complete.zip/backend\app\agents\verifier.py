from typing import Dict, Any

class VerifierAgent:
    def verify_step_execution(
        self,
        tool_name: str,
        tool_output: Dict[str, Any],
        verification_rule: str
    ) -> Dict[str, Any]:
        """Mathematically verifies actual tool results against the plan's verification criteria."""
        if not tool_output:
            return {
                "passed": False,
                "reason": "Tool execution returned empty or null output."
            }
        
        status = tool_output.get("status")
        if status in ("FAILED", "EXCURSION_DETECTED"):
            return {
                "passed": False,
                "reason": f"Tool reported operational failure or excursion: {tool_output.get('error_message', status)}"
            }

        # Specific rule verifications
        if tool_name == "inspect_inventory_telemetry":
            safe_temp = tool_output.get("temperature_within_safe_limits", False)
            hours = tool_output.get("hours_until_spoilage", 0)
            passed = safe_temp and hours > 0
            return {
                "passed": passed,
                "reason": "Telemetry verified: batch is within thermal safety limits with valid shelf life." if passed else "Batch is expired or spoiled."
            }

        elif tool_name == "match_recipient_network":
            matched = tool_output.get("total_matched_recipients", 0)
            passed = matched > 0
            return {
                "passed": passed,
                "reason": f"Recipient match verified: {matched} certified food banks have open capacity." if passed else "No eligible food banks found."
            }

        elif tool_name == "reserve_cold_freight":
            booked = tool_output.get("status") == "BOOKED"
            has_ref = bool(tool_output.get("booking_reference"))
            passed = booked and has_ref
            return {
                "passed": passed,
                "reason": f"Freight contract confirmed: Booking Ref {tool_output.get('booking_reference')} assigned." if passed else "Carrier reservation failed."
            }

        elif tool_name == "dispatch_transfer_manifest":
            dispatched = tool_output.get("status") == "DISPATCHED"
            passed = dispatched and bool(tool_output.get("manifest_id"))
            return {
                "passed": passed,
                "reason": f"Transfer manifest {tool_output.get('manifest_id')} issued with active tracking barcode." if passed else "Dispatch manifest failed."
            }

        elif tool_name == "verify_temperature_integrity":
            breach = tool_output.get("cold_chain_breach", True)
            haccp = tool_output.get("haccp_compliant", False)
            passed = (not breach) and haccp
            return {
                "passed": passed,
                "reason": f"HACCP cold-chain compliance verified: Mean temp {tool_output.get('mean_temp_c')}C (no excursions)." if passed else "Cold-chain excursion detected during transit."
            }

        elif tool_name == "finalize_chain_of_custody":
            passed = tool_output.get("chain_of_custody_closed", False)
            return {
                "passed": passed,
                "reason": f"Chain of custody closed with electronic signature {tool_output.get('electronic_receipt_hash')}." if passed else "Recipient handover incomplete."
            }

        elif tool_name == "calculate_impact_accounting":
            kg = tool_output.get("food_rescued_kg", 0)
            passed = kg > 0
            return {
                "passed": passed,
                "reason": f"Impact confirmed: {kg} kg rescued, {tool_output.get('meals_provided')} meals provided, {tool_output.get('co2e_averted_kg')} kg CO2e averted." if passed else "Impact calculation failed."
            }

        elif tool_name == "notify_ngo_coordinator":
            dispatched = tool_output.get("status") == "MESSAGE_DISPATCHED"
            has_id = bool(tool_output.get("message_id"))
            passed = dispatched and has_id
            return {
                "passed": passed,
                "reason": f"External alert {tool_output.get('message_id')} dispatched to {tool_output.get('recipient_name')} via {tool_output.get('channel')}." if passed else "NGO notification delivery failed."
            }

        elif tool_name == "confirm_donation_reservation":
            confirmed = tool_output.get("status") == "DONATION_CONFIRMED"
            has_res = bool(tool_output.get("reservation_id"))
            passed = confirmed and has_res
            return {
                "passed": passed,
                "reason": f"Reservation {tool_output.get('reservation_id')} confirmed for {tool_output.get('allocated_servings')} servings." if passed else "Donation reservation failed."
            }

        # Fallback verification
        passed = (status in ("SUCCESS", "BOOKED", "DISPATCHED", "COMPLETED", "MESSAGE_DISPATCHED", "DONATION_CONFIRMED"))
        return {
            "passed": passed,
            "reason": f"Status '{status}' verified." if passed else f"Status '{status}' does not meet success criteria."
        }

verifier_agent = VerifierAgent()
