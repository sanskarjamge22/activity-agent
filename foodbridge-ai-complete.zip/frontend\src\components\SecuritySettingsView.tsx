import React from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Terminal, 
  Sparkles, 
  Cloud, 
  CheckCircle2, 
  Key, 
  Cpu, 
  FileCode,
  Flame
} from 'lucide-react';

interface SecuritySettingsViewProps {
  demoMode: boolean;
}

export const SecuritySettingsView: React.FC<SecuritySettingsViewProps> = ({ demoMode }) => {
  const allowedTools = [
    { name: 'inspect_inventory_telemetry', sensitivity: 'SAFE_AUTONOMOUS', desc: 'Inspects IoT temperature sensors and perishability urgency.' },
    { name: 'match_recipient_network', sensitivity: 'SAFE_AUTONOMOUS', desc: 'Queries verified community food pantries by capacity and distance.' },
    { name: 'notify_ngo_coordinator', sensitivity: 'SENSITIVE_REQUIRES_APPROVAL', desc: 'Dispatches external SMS/Push alerts to NGO coordinators.' },
    { name: 'confirm_donation_reservation', sensitivity: 'SENSITIVE_REQUIRES_APPROVAL', desc: 'Locks food bank capacity under Good Samaritan protection.' },
    { name: 'reserve_cold_freight', sensitivity: 'SENSITIVE_REQUIRES_APPROVAL', desc: 'Contracts refrigerated transport vehicle and assigns driver.' },
    { name: 'dispatch_transfer_manifest', sensitivity: 'SENSITIVE_REQUIRES_APPROVAL', desc: 'Issues legal transfer manifest and generates tracking barcode.' },
    { name: 'verify_temperature_integrity', sensitivity: 'SAFE_AUTONOMOUS', desc: 'Post-transit HACCP temperature compliance verification.' },
    { name: 'finalize_chain_of_custody', sensitivity: 'SAFE_AUTONOMOUS', desc: 'Recipient digital signature and liability closure.' },
    { name: 'calculate_impact_accounting', sensitivity: 'SAFE_AUTONOMOUS', desc: 'Calculates kg rescued, meals provided, and CO2e averted.' }
  ];

  return (
    <div style={{ maxWidth: '960px', margin: '0 auto' }}>
      
      {/* Header */}
      <div className="glass-panel" style={{ padding: '1.75rem', marginBottom: '1.5rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.5rem' }}>
          <div style={{ padding: '0.5rem', borderRadius: '0.5rem', background: 'rgba(16, 185, 129, 0.2)', color: '#34d399' }}>
            <ShieldCheck size={26} />
          </div>
          <div>
            <h2 style={{ fontSize: '1.4rem', fontWeight: 800, color: '#f8fafc' }}>
              Security Architecture & Governance
            </h2>
            <p style={{ fontSize: '0.825rem', color: '#94a3b8' }}>
              Zero Trust Agent Execution • Human Approval Gates • Google Cloud Integration
            </p>
          </div>
        </div>
      </div>

      {/* Grid of Security Pillars */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.25rem', marginBottom: '1.5rem' }}>
        
        {/* Prompt Injection Defense */}
        <div className="glass-panel" style={{ padding: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
            <Lock size={18} color="#10b981" />
            <h3 style={{ fontSize: '0.95rem', fontWeight: 700, color: '#f8fafc' }}>
              Prompt Injection Defense
            </h3>
          </div>
          <p style={{ fontSize: '0.8rem', color: '#cbd5e1', marginBottom: '0.75rem' }}>
            Multi-stage firewall detects instruction override patterns (e.g. <code>ignore instructions</code>, <code>developer mode</code>, <code>bypass safety</code>) and sanitizes delimiter breakouts.
          </p>
          <span className="badge badge-success">Enforced Server-Side</span>
        </div>

        {/* Human-in-the-Loop Gating */}
        <div className="glass-panel" style={{ padding: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
            <Flame size={18} color="#f59e0b" />
            <h3 style={{ fontSize: '0.95rem', fontWeight: 700, color: '#f8fafc' }}>
              Human Approval Gates
            </h3>
          </div>
          <p style={{ fontSize: '0.8rem', color: '#cbd5e1', marginBottom: '0.75rem' }}>
            Consequential actions (carrier freight contracts, legal custody transfer, external notifications) pause the state machine until an authorized human dispatcher signs off.
          </p>
          <span className="badge badge-warning">Zero Autonomous Dispatches</span>
        </div>

        {/* Idempotency Protection */}
        <div className="glass-panel" style={{ padding: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
            <Key size={18} color="#06b6d4" />
            <h3 style={{ fontSize: '0.95rem', fontWeight: 700, color: '#f8fafc' }}>
              Idempotency Collision Guard
            </h3>
          </div>
          <p style={{ fontSize: '0.8rem', color: '#cbd5e1', marginBottom: '0.75rem' }}>
            Client-supplied <code>Idempotency-Key</code> headers prevent double-booking or duplicate external alerts on flaky cellular connections. Replays return HTTP 409 Conflict.
          </p>
          <span className="badge badge-cyan">Active Protection</span>
        </div>

      </div>

      {/* Google Tech Stack Section */}
      <div className="glass-panel" style={{ padding: '1.5rem', marginBottom: '1.5rem' }}>
        <h3 style={{ fontSize: '1.1rem', fontWeight: 700, color: '#f8fafc', marginBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <Cloud size={20} color="#38bdf8" /> Google Technologies Integration
        </h3>
        <p style={{ fontSize: '0.85rem', color: '#cbd5e1', marginBottom: '1rem' }}>
          FoodBridge AI is architected specifically around the Google Cloud and AI ecosystem:
        </p>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '1rem' }}>
          <div style={{ background: 'rgba(0, 0, 0, 0.3)', padding: '1rem', borderRadius: '0.75rem', border: '1px solid var(--border-color)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem', color: '#38bdf8', fontWeight: 700, fontSize: '0.85rem' }}>
              <Cpu size={16} /> Google Gemini 2.5 / Flash
            </div>
            <p style={{ fontSize: '0.75rem', color: '#94a3b8' }}>
              Powers structured agent reasoning, perishability anomaly analysis, and action DAG planning with JSON schema constraints.
            </p>
          </div>

          <div style={{ background: 'rgba(0, 0, 0, 0.3)', padding: '1rem', borderRadius: '0.75rem', border: '1px solid var(--border-color)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem', color: '#34d399', fontWeight: 700, fontSize: '0.85rem' }}>
              <Cloud size={16} /> Google Cloud Run
            </div>
            <p style={{ fontSize: '0.75rem', color: '#94a3b8' }}>
              Containerized with minimal cold starts, autoscaling, and zero persistent attack surface. Deployment script included.
            </p>
          </div>

          <div style={{ background: 'rgba(0, 0, 0, 0.3)', padding: '1rem', borderRadius: '0.75rem', border: '1px solid var(--border-color)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem', color: '#fbbf24', fontWeight: 700, fontSize: '0.85rem' }}>
              <Sparkles size={16} /> Deterministic Demo Mode
            </div>
            <p style={{ fontSize: '0.75rem', color: '#94a3b8' }}>
              {demoMode 
                ? 'Active: Operates smoothly without external API credentials using high-fidelity IoT simulation.' 
                : 'Live: Connected to Google Gemini REST endpoints with environment key.'}
            </p>
          </div>
        </div>
      </div>

      {/* Tool Allowlist Table */}
      <div className="glass-panel" style={{ padding: '1.5rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
          <div>
            <h3 style={{ fontSize: '1.1rem', fontWeight: 700, color: '#f8fafc' }}>
              Authorized Tool Allowlist (9 Registered Tools)
            </h3>
            <p style={{ fontSize: '0.75rem', color: '#94a3b8' }}>
              Unregistered tool invocations or arbitrary shell commands are blocked by policy
            </p>
          </div>
          <span className="badge badge-success">Allowlist Enforced</span>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
          {allowedTools.map((t) => (
            <div
              key={t.name}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '0.75rem 1rem',
                borderRadius: '0.5rem',
                background: 'rgba(255, 255, 255, 0.03)',
                border: '1px solid var(--border-color)'
              }}
            >
              <div>
                <code style={{ fontSize: '0.85rem', color: '#38bdf8', fontWeight: 600 }}>{t.name}()</code>
                <p style={{ fontSize: '0.75rem', color: '#94a3b8', marginTop: '0.15rem' }}>{t.desc}</p>
              </div>
              <span className={`badge ${t.sensitivity === 'SENSITIVE_REQUIRES_APPROVAL' ? 'badge-warning' : 'badge-success'}`}>
                {t.sensitivity === 'SENSITIVE_REQUIRES_APPROVAL' ? 'Gate Required' : 'Autonomous'}
              </span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
