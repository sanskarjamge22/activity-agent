import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.models.database import db

client = TestClient(app)

def test_sqlite_listings_crud():
    # 1. Create listing
    payload = {
        "title": "Engineering Quad Evening Sandwiches",
        "description": "50 freshly prepared vegetarian panini sandwiches from campus cafe.",
        "warehouse_id": "CANTEEN-ENG-QUAD",
        "inventory_batch_id": "BATCH-PANINI-101",
        "donor_name": "Engineering Quad Dining Hub",
        "donor_type": "COLLEGE_CANTEEN",
        "food_category": "PREPARED_HOT_MEALS",
        "estimated_servings": 50,
        "weight_kg": 20.0,
        "safe_consumption_window_hours": 4.0,
        "pickup_address": "Hearst Memorial Mining Plaza, Berkeley, CA"
    }
    res = client.post("/api/listings", json=payload)
    assert res.status_code == 200
    wf = res.json()
    listing_id = wf["incident_id"]

    # 2. View all listings from SQLite
    list_res = client.get("/api/listings")
    assert list_res.status_code == 200
    listings = list_res.json()
    assert len(listings) >= 1
    found = next((l for l in listings if l["listing_id"] == listing_id), None)
    assert found is not None
    assert found["title"] == payload["title"]
    assert found["estimated_servings"] == 50

    # 3. View single listing
    single_res = client.get(f"/api/listings/{listing_id}")
    assert single_res.status_code == 200
    assert single_res.json()["listing_id"] == listing_id

    # 4. Update listing status
    patch_res = client.patch(
        f"/api/listings/{listing_id}",
        json={"status": "RESERVED", "notes": "Hold for Hope Community Kitchen pickup"}
    )
    assert patch_res.status_code == 200
    updated_single = client.get(f"/api/listings/{listing_id}").json()
    assert updated_single["status"] == "RESERVED"

def test_recipient_matching_algorithm():
    match_payload = {
        "food_category": "PREPARED_HOT_MEALS",
        "servings": 80,
        "weight_kg": 40.0,
        "max_distance_km": 15.0,
        "require_refrigeration": True
    }
    res = client.post("/api/recipients/match", json=match_payload)
    assert res.status_code == 200
    data = res.json()
    assert data["total_matched"] >= 1
    best = data["best_match"]
    assert best is not None
    assert "match_score" in best
    assert best["recipient"]["distance_km"] <= 15.0

def test_temperature_validation_safe_cold():
    res = client.post(
        "/api/safety/validate-temperature",
        json={"food_category": "CHILLED_DAIRY", "temperature_c": 3.2}
    )
    assert res.status_code == 200
    data = res.json()
    assert data["is_safe"] is True
    assert data["haccp_compliant"] is True
    assert data["status"] == "COMPLIANT"

def test_temperature_validation_danger_zone():
    # Warm holding hot food at 25C is in dangerous zone (5C-59C)
    res = client.post(
        "/api/safety/validate-temperature",
        json={"food_category": "PREPARED_HOT_MEALS", "temperature_c": 25.0}
    )
    assert res.status_code == 200
    data = res.json()
    assert data["is_safe"] is False
    assert data["status"] == "DANGER_ZONE_VIOLATION"
    assert "CRITICAL" in data["action_recommended"]

def test_impact_calculation():
    res = client.post(
        "/api/analytics/calculate-impact",
        json={"food_category": "CHILLED_DAIRY", "weight_kg": 100.0}
    )
    assert res.status_code == 200
    data = res.json()
    assert data["weight_kg"] == 100.0
    assert data["meals_rescued"] == 220
    assert data["co2e_averted_kg"] == 280.0  # 100 * 2.8
    assert data["financial_value_usd"] == 450.0
    assert data["water_conserved_liters"] == 35000
