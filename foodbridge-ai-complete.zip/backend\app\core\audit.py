import uuid
import json
from datetime import datetime
from typing import Dict, Any, List
from app.models.schemas import AuditLogEntry
from app.core.security import SecurityManager

GENESIS_HASH = "0000000000000000000000000000000000000000000000000000000000000000"

class AuditManager:
    def __init__(self):
        self._entries: List[AuditLogEntry] = []
        self._latest_hash: str = GENESIS_HASH
        self._load_from_db()

    def _load_from_db(self):
        """Loads historical audit events from persistent SQLite database."""
        try:
            from app.models.database import db
            rows = db.get_audit_logs()
            for r in rows:
                entry = AuditLogEntry(
                    entry_id=r["entry_id"],
                    workflow_id=r["workflow_id"],
                    timestamp=datetime.fromisoformat(r["timestamp"]) if isinstance(r["timestamp"], str) else r["timestamp"],
                    event_type=r["event_type"],
                    actor=r["actor"],
                    details=r["details"],
                    prev_hash=r["prev_hash"],
                    current_hash=r["current_hash"]
                )
                self._entries.append(entry)
                self._latest_hash = entry.current_hash
        except Exception:
            pass

    def log_event(
        self,
        workflow_id: str,
        event_type: str,
        actor: str,
        details: Dict[str, Any]
    ) -> AuditLogEntry:
        """Appends a new event and computes the sequential HMAC hash."""
        entry_id = f"aud-{uuid.uuid4().hex[:12]}"
        now = datetime.utcnow()
        
        # Serialize details deterministically
        details_str = json.dumps(details, sort_keys=True, default=str)
        payload = f"{entry_id}|{workflow_id}|{event_type}|{actor}|{now.isoformat()}|{details_str}"
        current_hash = SecurityManager.compute_audit_hash(self._latest_hash, payload)
        
        entry = AuditLogEntry(
            entry_id=entry_id,
            workflow_id=workflow_id,
            timestamp=now,
            event_type=event_type,
            actor=actor,
            details=details,
            prev_hash=self._latest_hash,
            current_hash=current_hash
        )
        
        self._entries.append(entry)
        self._latest_hash = current_hash

        # Persist to SQLite
        try:
            from app.models.database import db
            db.save_audit_log({
                "entry_id": entry.entry_id,
                "workflow_id": entry.workflow_id,
                "timestamp": entry.timestamp,
                "event_type": entry.event_type,
                "actor": entry.actor,
                "details": entry.details,
                "prev_hash": entry.prev_hash,
                "current_hash": entry.current_hash
            })
        except Exception:
            pass

        return entry

    def get_entries(self, workflow_id: str = None) -> List[AuditLogEntry]:
        if workflow_id:
            return [e for e in self._entries if e.workflow_id == workflow_id]
        return list(self._entries)

    def verify_chain_integrity(self) -> Dict[str, Any]:
        """Validates that no historical audit log entries have been altered."""
        current_expected_prev = GENESIS_HASH
        for idx, entry in enumerate(self._entries):
            if entry.prev_hash != current_expected_prev:
                return {
                    "valid": False,
                    "tampered_index": idx,
                    "tampered_entry_id": entry.entry_id,
                    "reason": "Previous hash pointer mismatch"
                }
            
            # Recalculate hash
            details_str = json.dumps(entry.details, sort_keys=True, default=str)
            payload = f"{entry.entry_id}|{entry.workflow_id}|{entry.event_type}|{entry.actor}|{entry.timestamp.isoformat()}|{details_str}"
            recomputed = SecurityManager.compute_audit_hash(entry.prev_hash, payload)
            
            if recomputed != entry.current_hash:
                return {
                    "valid": False,
                    "tampered_index": idx,
                    "tampered_entry_id": entry.entry_id,
                    "reason": "HMAC signature mismatch"
                }
            
            current_expected_prev = entry.current_hash

        return {
            "valid": True,
            "total_entries_verified": len(self._entries),
            "latest_head_hash": self._latest_hash
        }

# Global singleton
audit_manager = AuditManager()
