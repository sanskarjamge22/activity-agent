import {
  WorkflowExecution,
  SystemMetrics,
  AuditLogEntry,
  RecipientNGO,
  DonorProfile,
  UserRole
} from '../types';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

function getHeaders(userRole: UserRole, userId = 'usr-current', idempotencyKey?: string): HeadersInit {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'X-User-Role': userRole,
    'X-User-Id': userId
  };
  if (idempotencyKey) {
    headers['Idempotency-Key'] = idempotencyKey;
  }
  return headers;
}

export const api = {
  async getHealth() {
    const res = await fetch(`${API_BASE_URL}/api/health`);
    if (!res.ok) throw new Error('Health check failed');
    return res.json();
  },

  async getMetrics(): Promise<SystemMetrics> {
    const res = await fetch(`${API_BASE_URL}/api/metrics`);
    if (!res.ok) throw new Error('Failed to fetch metrics');
    return res.json();
  },

  async getSampleData(): Promise<{
    donors: DonorProfile[];
    recipients: RecipientNGO[];
    warehouses: any[];
    inventories: any[];
    carriers: any[];
  }> {
    const res = await fetch(`${API_BASE_URL}/api/sample-data`);
    if (!res.ok) throw new Error('Failed to fetch sample data');
    return res.json();
  },

  async getWorkflows(): Promise<WorkflowExecution[]> {
    const res = await fetch(`${API_BASE_URL}/api/workflows`);
    if (!res.ok) throw new Error('Failed to fetch workflows');
    return res.json();
  },

  async getWorkflow(workflowId: string): Promise<WorkflowExecution> {
    const res = await fetch(`${API_BASE_URL}/api/workflows/${workflowId}`);
    if (!res.ok) throw new Error(`Failed to fetch workflow ${workflowId}`);
    return res.json();
  },

  async createSurplusListing(
    payload: {
      title: string;
      description: string;
      warehouse_id?: string;
      inventory_batch_id?: string;
      donor_name?: string;
      donor_type?: string;
      food_category?: string;
      estimated_servings?: number;
      weight_kg?: number;
      safe_consumption_window_hours?: number;
      dietary_tags?: string[];
      pickup_address?: string;
      max_budget_usd?: number;
      max_transit_hours?: number;
      require_refrigeration?: boolean;
      notes?: string;
    },
    userRole: UserRole,
    idempotencyKey?: string
  ): Promise<WorkflowExecution> {
    const res = await fetch(`${API_BASE_URL}/api/listings`, {
      method: 'POST',
      headers: getHeaders(userRole, 'usr-donor-01', idempotencyKey),
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: 'Failed to create surplus listing' }));
      throw new Error(err.detail || 'Failed to create listing');
    }
    return res.json();
  },

  async advanceWorkflow(workflowId: string, userRole: UserRole): Promise<WorkflowExecution> {
    const res = await fetch(`${API_BASE_URL}/api/workflows/${workflowId}/advance`, {
      method: 'POST',
      headers: getHeaders(userRole, 'usr-operator-01')
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: 'Failed to advance workflow' }));
      throw new Error(err.detail || 'Advance step failed');
    }
    return res.json();
  },

  async autoExecuteWorkflow(workflowId: string, userRole: UserRole): Promise<WorkflowExecution> {
    const res = await fetch(`${API_BASE_URL}/api/workflows/${workflowId}/auto-execute`, {
      method: 'POST',
      headers: getHeaders(userRole, 'usr-operator-01')
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: 'Failed to auto-execute' }));
      throw new Error(err.detail || 'Auto-execute failed');
    }
    return res.json();
  },

  async submitApproval(
    workflowId: string,
    stepId: string,
    decision: 'APPROVE' | 'REJECT',
    decidedBy: string,
    reason: string,
    userRole: UserRole
  ): Promise<WorkflowExecution> {
    const res = await fetch(`${API_BASE_URL}/api/workflows/${workflowId}/approve`, {
      method: 'POST',
      headers: getHeaders(userRole, decidedBy),
      body: JSON.stringify({
        step_id: stepId,
        decision,
        decided_by: decidedBy,
        reason
      })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: 'Approval submission failed' }));
      throw new Error(err.detail || 'Approval failed');
    }
    return res.json();
  },

  async getAuditLogs(workflowId?: string): Promise<AuditLogEntry[]> {
    const url = workflowId
      ? `${API_BASE_URL}/api/audit-logs?workflow_id=${encodeURIComponent(workflowId)}`
      : `${API_BASE_URL}/api/audit-logs`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('Failed to fetch audit logs');
    return res.json();
  },

  async verifyAuditIntegrity(): Promise<{
    valid: boolean;
    total_entries_verified: number;
    latest_head_hash: string;
    tampered_index?: number;
  }> {
    const res = await fetch(`${API_BASE_URL}/api/audit-logs/verify`);
    if (!res.ok) throw new Error('Failed to verify audit integrity');
    return res.json();
  },

  async getSettings(userRole: UserRole) {
    const res = await fetch(`${API_BASE_URL}/api/settings`, {
      headers: getHeaders(userRole)
    });
    if (!res.ok) throw new Error('Failed to fetch settings');
    return res.json();
  },

  async validateTemperature(foodCategory: string, temperatureC: number, holdingDurationHours = 1.0) {
    const res = await fetch(`${API_BASE_URL}/api/safety/validate-temperature`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        food_category: foodCategory,
        temperature_c: temperatureC,
        holding_duration_hours: holdingDurationHours
      })
    });
    if (!res.ok) throw new Error('Temperature validation request failed');
    return res.json();
  },

  async calculateImpact(foodCategory: string, weightKg: number) {
    const res = await fetch(`${API_BASE_URL}/api/analytics/calculate-impact`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        food_category: foodCategory,
        weight_kg: weightKg
      })
    });
    if (!res.ok) throw new Error('Impact calculation request failed');
    return res.json();
  },

  async matchRecipients(foodCategory: string, servings: number, weightKg: number, maxDistanceKm = 25.0, requireRefrigeration = false) {
    const res = await fetch(`${API_BASE_URL}/api/recipients/match`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        food_category: foodCategory,
        servings,
        weight_kg: weightKg,
        max_distance_km: maxDistanceKm,
        require_refrigeration: requireRefrigeration
      })
    });
    if (!res.ok) throw new Error('Recipient match request failed');
    return res.json();
  },

  async updateListingStatus(listingId: string, status: string, notes?: string, userRole: UserRole = 'dispatcher') {
    const res = await fetch(`${API_BASE_URL}/api/listings/${listingId}`, {
      method: 'PATCH',
      headers: getHeaders(userRole),
      body: JSON.stringify({ status, notes })
    });
    if (!res.ok) throw new Error('Failed to update listing status');
    return res.json();
  }
};
