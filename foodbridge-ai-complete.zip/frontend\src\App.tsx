import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { CreateListingView } from './components/CreateListingView';
import { PlanVisualizerView } from './components/PlanVisualizerView';
import { ApprovalGateModal } from './components/ApprovalGateModal';
import { AuditTrailView } from './components/AuditTrailView';
import { SecuritySettingsView } from './components/SecuritySettingsView';
import { api } from './services/api';
import { 
  WorkflowExecution, 
  SystemMetrics, 
  DonorProfile, 
  RecipientNGO, 
  AuditLogEntry, 
  PlanStep, 
  UserRole 
} from './types';

export function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [userRole, setUserRole] = useState<UserRole>('dispatcher');
  const [demoMode, setDemoMode] = useState<boolean>(true);
  
  const [metrics, setMetrics] = useState<SystemMetrics | null>(null);
  const [workflows, setWorkflows] = useState<WorkflowExecution[]>([]);
  const [selectedWorkflow, setSelectedWorkflow] = useState<WorkflowExecution | null>(null);
  const [donors, setDonors] = useState<DonorProfile[]>([]);
  const [recipients, setRecipients] = useState<RecipientNGO[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  
  const [activeModalStep, setActiveModalStep] = useState<PlanStep | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isActionLoading, setIsActionLoading] = useState<boolean>(false);
  const [isVerifyingAudit, setIsVerifyingAudit] = useState<boolean>(false);
  const [isQuickDemoLoading, setIsQuickDemoLoading] = useState<boolean>(false);

  // Initial Data Fetch
  const loadInitialData = async () => {
    try {
      const [m, wfList, sample, logs, health] = await Promise.all([
        api.getMetrics().catch(() => null),
        api.getWorkflows().catch(() => []),
        api.getSampleData().catch(() => ({ donors: [], recipients: [], warehouses: [], inventories: [], carriers: [] })),
        api.getAuditLogs().catch(() => []),
        api.getHealth().catch(() => ({ demo_mode: true }))
      ]);

      if (m) setMetrics(m);
      if (wfList && wfList.length > 0) {
        setWorkflows(wfList);
        // Default to latest active or first workflow
        const activeOne = wfList.find((w: WorkflowExecution) => w.status === 'AWAITING_APPROVAL' || w.status === 'EXECUTING');
        setSelectedWorkflow(activeOne || wfList[0]);
      }
      if (sample) {
        setDonors(sample.donors || []);
        setRecipients(sample.recipients || []);
      }
      if (logs) setAuditLogs(logs);
      if (health) setDemoMode(health.demo_mode);
    } catch (err) {
      console.error('Error loading initial data', err);
    }
  };

  useEffect(() => {
    loadInitialData();
  }, []);

  // Calculate pending approval actions across all workflows
  const pendingApprovalsCount = workflows.filter(
    (w) => w.status === 'AWAITING_APPROVAL' || w.plan?.steps[w.current_step_index]?.status === 'AWAITING_APPROVAL'
  ).length;

  // Handler: Create Surplus Listing
  const handleCreateListing = async (formData: any) => {
    setIsSubmitting(true);
    try {
      const newWf = await api.createSurplusListing(formData, userRole);
      setWorkflows((prev) => [newWf, ...prev]);
      setSelectedWorkflow(newWf);
      setActiveTab('plan');
      // Refresh metrics and audit log
      api.getMetrics().then(setMetrics).catch(() => {});
      api.getAuditLogs().then(setAuditLogs).catch(() => {});
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handler: Quick 1-Click Canteen Demo
  const handleQuickDemo = async () => {
    setIsQuickDemoLoading(true);
    try {
      const demoPayload = {
        title: "North Campus Dinner Surplus - 85 Mediterranean Bowls",
        description: "85 portions of warm turmeric rice, roasted halal chicken, and grilled seasonal vegetables. Prepared at 18:00, held at safe warm holding temp.",
        warehouse_id: "CANTEEN-CAMPUS-NORTH",
        inventory_batch_id: `BATCH-${Date.now().toString().slice(-6)}`,
        donor_name: "North Campus Student Dining Hall",
        donor_type: "COLLEGE_CANTEEN",
        food_category: "PREPARED_HOT_MEALS",
        estimated_servings: 85,
        weight_kg: 42.5,
        safe_consumption_window_hours: 4.0,
        dietary_tags: ["Halal", "Vegetarian Options"],
        pickup_address: "North Campus Commons, Berkeley, CA",
        max_budget_usd: 50.0,
        max_transit_hours: 1.5,
        require_refrigeration: false
      };
      const newWf = await api.createSurplusListing(demoPayload, userRole);
      setWorkflows((prev) => [newWf, ...prev]);
      setSelectedWorkflow(newWf);
      setActiveTab('plan');
      api.getMetrics().then(setMetrics).catch(() => {});
      api.getAuditLogs().then(setAuditLogs).catch(() => {});
    } finally {
      setIsQuickDemoLoading(false);
    }
  };

  // Handler: Advance Step
  const handleAdvanceStep = async () => {
    if (!selectedWorkflow) return;
    setIsActionLoading(true);
    try {
      const updated = await api.advanceWorkflow(selectedWorkflow.workflow_id, userRole);
      setSelectedWorkflow(updated);
      setWorkflows((prev) => prev.map((w) => (w.workflow_id === updated.workflow_id ? updated : w)));
      
      // If it hit an approval gate, prompt the modal
      const curStep = updated.plan?.steps[updated.current_step_index];
      if (updated.status === 'AWAITING_APPROVAL' && curStep) {
        setActiveModalStep(curStep);
      }

      api.getMetrics().then(setMetrics).catch(() => {});
      api.getAuditLogs().then(setAuditLogs).catch(() => {});
    } finally {
      setIsActionLoading(false);
    }
  };

  // Handler: Auto-Execute
  const handleAutoExecute = async () => {
    if (!selectedWorkflow) return;
    setIsActionLoading(true);
    try {
      const updated = await api.autoExecuteWorkflow(selectedWorkflow.workflow_id, userRole);
      setSelectedWorkflow(updated);
      setWorkflows((prev) => prev.map((w) => (w.workflow_id === updated.workflow_id ? updated : w)));
      
      const curStep = updated.plan?.steps[updated.current_step_index];
      if (updated.status === 'AWAITING_APPROVAL' && curStep) {
        setActiveModalStep(curStep);
      }

      api.getMetrics().then(setMetrics).catch(() => {});
      api.getAuditLogs().then(setAuditLogs).catch(() => {});
    } finally {
      setIsActionLoading(false);
    }
  };

  // Handler: Submit Approval Decision
  const handleApprovalDecision = async (decision: 'APPROVE' | 'REJECT', decidedBy: string, reason: string) => {
    if (!selectedWorkflow || !activeModalStep) return;
    setIsSubmitting(true);
    try {
      const updated = await api.submitApproval(
        selectedWorkflow.workflow_id,
        activeModalStep.step_id,
        decision,
        decidedBy,
        reason,
        userRole
      );
      setSelectedWorkflow(updated);
      setWorkflows((prev) => prev.map((w) => (w.workflow_id === updated.workflow_id ? updated : w)));
      setActiveModalStep(null);
      
      api.getMetrics().then(setMetrics).catch(() => {});
      api.getAuditLogs().then(setAuditLogs).catch(() => {});
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handler: Verify Audit Trail
  const handleVerifyAudit = async () => {
    setIsVerifyingAudit(true);
    try {
      return await api.verifyAuditIntegrity();
    } finally {
      setIsVerifyingAudit(false);
    }
  };

  return (
    <div className="app-container">
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        userRole={userRole}
        setUserRole={setUserRole}
        pendingApprovalsCount={pendingApprovalsCount}
        demoMode={demoMode}
      />

      {/* Main Content Area */}
      <main>
        {activeTab === 'dashboard' && (
          <DashboardView
            metrics={metrics}
            workflows={workflows}
            donors={donors}
            recipients={recipients}
            onSelectWorkflow={(wf) => {
              setSelectedWorkflow(wf);
              setActiveTab('plan');
            }}
            onCreateClick={() => setActiveTab('create')}
            onQuickDemoClick={handleQuickDemo}
            isQuickDemoLoading={isQuickDemoLoading}
          />
        )}

        {activeTab === 'create' && (
          <CreateListingView
            donors={donors}
            onSubmit={handleCreateListing}
            userRole={userRole}
            isSubmitting={isSubmitting}
          />
        )}

        {activeTab === 'plan' && (
          <PlanVisualizerView
            workflow={selectedWorkflow}
            onAdvanceStep={handleAdvanceStep}
            onAutoExecute={handleAutoExecute}
            onOpenApprovalModal={(step) => setActiveModalStep(step)}
            userRole={userRole}
            isActionLoading={isActionLoading}
          />
        )}

        {activeTab === 'approvals' && (
          <div>
            <div className="glass-panel" style={{ padding: '1.5rem', marginBottom: '1.5rem' }}>
              <h2 style={{ fontSize: '1.4rem', fontWeight: 800, color: '#f8fafc', marginBottom: '0.25rem' }}>
                Human Approval Gate Center
              </h2>
              <p style={{ fontSize: '0.85rem', color: '#cbd5e1' }}>
                Review and sign off on high-impact logistics bookings, custody transfer manifests, and external alerts.
              </p>
            </div>

            {pendingApprovalsCount === 0 ? (
              <div className="glass-panel" style={{ padding: '3rem', textAlign: 'center' }}>
                <div style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>🛡️</div>
                <h3 style={{ fontSize: '1.15rem', fontWeight: 700, color: '#34d399', marginBottom: '0.5rem' }}>
                  All Gate Actions Authorized
                </h3>
                <p style={{ color: '#94a3b8', fontSize: '0.85rem' }}>
                  There are no pending human approvals at this moment. You can advance active workflows or create a new listing.
                </p>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                {workflows
                  .filter((w) => w.status === 'AWAITING_APPROVAL' || w.plan?.steps[w.current_step_index]?.status === 'AWAITING_APPROVAL')
                  .map((wf) => {
                    const step = wf.plan?.steps[wf.current_step_index];
                    return (
                      <div
                        key={wf.workflow_id}
                        className="glass-panel pulse-amber"
                        style={{ padding: '1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}
                      >
                        <div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem' }}>
                            <span className="badge badge-warning">Awaiting Authorization</span>
                            <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>{wf.workflow_id}</span>
                          </div>
                          <h4 style={{ fontSize: '1.1rem', fontWeight: 700, color: '#f8fafc' }}>
                            {step?.title || wf.title}
                          </h4>
                          <p style={{ fontSize: '0.8rem', color: '#cbd5e1', marginTop: '0.25rem' }}>
                            {step?.description}
                          </p>
                        </div>
                        <button
                          className="btn-primary"
                          style={{ background: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)' }}
                          onClick={() => {
                            setSelectedWorkflow(wf);
                            if (step) setActiveModalStep(step);
                          }}
                        >
                          Review & Decide &rarr;
                        </button>
                      </div>
                    );
                  })}
              </div>
            )}
          </div>
        )}

        {activeTab === 'audit' && (
          <AuditTrailView
            logs={auditLogs}
            onVerifyIntegrity={handleVerifyAudit}
            onRefresh={async () => {
              const l = await api.getAuditLogs();
              setAuditLogs(l);
            }}
            isVerifying={isVerifyingAudit}
          />
        )}

        {activeTab === 'settings' && (
          <SecuritySettingsView demoMode={demoMode} />
        )}
      </main>

      {/* Human Approval Gate Modal */}
      {activeModalStep && selectedWorkflow && (
        <ApprovalGateModal
          step={activeModalStep}
          workflowId={selectedWorkflow.workflow_id}
          userRole={userRole}
          onDecision={handleApprovalDecision}
          onClose={() => setActiveModalStep(null)}
          isSubmitting={isSubmitting}
        />
      )}
    </div>
  );
}

export default App;
