from typing import Any, Dict, List

# FoodBridge AI Donors: Restaurants and College Canteens
SAMPLE_DONORS: Dict[str, Dict[str, Any]] = {
    "CANTEEN-CAMPUS-NORTH": {
        "donor_id": "CANTEEN-CAMPUS-NORTH",
        "name": "North Campus Student Dining Hall",
        "type": "COLLEGE_CANTEEN",
        "location": "North Campus Commons, Berkeley, CA",
        "contact_person": "Chef Marcus Vance",
        "contact_phone": "+1-510-555-0192",
        "operating_hours": "07:00 - 21:30",
        "refrigeration_available": True
    },
    "REST-BISTRO-DOWNTOWN": {
        "donor_id": "REST-BISTRO-DOWNTOWN",
        "name": "The Olive Branch Mediterranean Bistro",
        "type": "RESTAURANT",
        "location": "1420 Shattuck Ave, Berkeley, CA",
        "contact_person": "Elena Rostova (General Manager)",
        "contact_phone": "+1-510-555-0144",
        "operating_hours": "11:00 - 23:00",
        "refrigeration_available": True
    },
    "CANTEEN-ENG-QUAD": {
        "donor_id": "CANTEEN-ENG-QUAD",
        "name": "Engineering Quad Dining Hub",
        "type": "COLLEGE_CANTEEN",
        "location": "Hearst Memorial Mining Plaza, CA",
        "contact_person": "Aisha Patel (Catering Lead)",
        "contact_phone": "+1-510-555-0188",
        "operating_hours": "08:00 - 19:00",
        "refrigeration_available": True
    },
    "REST-ARTISAN-BAKERY": {
        "donor_id": "REST-ARTISAN-BAKERY",
        "name": "Golden Crust Artisan Bakery & Cafe",
        "type": "BAKERY",
        "location": "2100 University Ave, Berkeley, CA",
        "contact_person": "David Kim (Master Baker)",
        "contact_phone": "+1-510-555-0131",
        "operating_hours": "06:00 - 18:00",
        "refrigeration_available": False
    }
}

SAMPLE_WAREHOUSES: Dict[str, Dict[str, Any]] = {
    "WH-WEST-01": {
        "id": "WH-WEST-01",
        "name": "Pacific Cold Storage Hub #4",
        "location": "Oakland, CA",
        "coordinates": {"lat": 37.8044, "lng": -122.2712},
        "zones": ["Freezer-A (-18C)", "Chilled-B (+3C)", "Ambient-C (+18C)"],
        "telemetry_health": "ONLINE",
    },
    "WH-SOUTH-02": {
        "id": "WH-SOUTH-02",
        "name": "Valley Distribution Depot",
        "location": "San Jose, CA",
        "coordinates": {"lat": 37.3382, "lng": -121.8863},
        "zones": ["Chilled-1 (+2C)", "Chilled-2 (+4C)"],
        "telemetry_health": "ONLINE",
    }
}

SAMPLE_INVENTORIES: Dict[str, Dict[str, Any]] = {
    "BATCH-DAIRY-802": {
        "batch_id": "BATCH-DAIRY-802",
        "warehouse_id": "WH-WEST-01",
        "commodity": "Organic Greek Yogurt & Whole Milk",
        "category": "Perishable Dairy",
        "quantity_kg": 1420.0,
        "est_retail_value_usd": 6800.0,
        "current_temp_c": 3.4,
        "min_safe_temp_c": 1.0,
        "max_safe_temp_c": 4.5,
        "shelf_life_remaining_hours": 36.0,
        "status": "AT_RISK_EXPIRY",
        "co2e_per_kg": 2.8,  # kg CO2e averted per kg dairy rescued
        "meals_multiplier": 2.2  # 1 kg = 2.2 meals
    },
    "BATCH-BERRY-415": {
        "batch_id": "BATCH-BERRY-415",
        "warehouse_id": "WH-WEST-01",
        "commodity": "Fresh Strawberries & Blueberries",
        "category": "Fresh Produce",
        "quantity_kg": 850.0,
        "est_retail_value_usd": 4200.0,
        "current_temp_c": 2.8,
        "min_safe_temp_c": 1.0,
        "max_safe_temp_c": 5.0,
        "shelf_life_remaining_hours": 24.0,
        "status": "URGENT_SURPLUS",
        "co2e_per_kg": 1.4,
        "meals_multiplier": 1.8
    },
    "BATCH-MEAT-109": {
        "batch_id": "BATCH-MEAT-109",
        "warehouse_id": "WH-SOUTH-02",
        "commodity": "Chilled Free-Range Poultry",
        "category": "Proteins",
        "quantity_kg": 620.0,
        "est_retail_value_usd": 5100.0,
        "current_temp_c": 2.1,
        "min_safe_temp_c": 0.5,
        "max_safe_temp_c": 3.5,
        "shelf_life_remaining_hours": 18.0,
        "status": "IMMINENT_CRITICAL",
        "co2e_per_kg": 6.1,
        "meals_multiplier": 2.5
    }
}

SAMPLE_RECIPIENTS: List[Dict[str, Any]] = [
    {
        "recipient_id": "NGO-CAMPUS-PANTRY",
        "name": "Student Care Mutual Aid Pantry",
        "address": "Barrow Lane Basement, UC Berkeley, CA",
        "distance_km": 0.8,
        "transit_time_minutes": 8,
        "accepts_categories": ["Prepared Meals", "Fresh Bakery", "Perishable Dairy", "Fresh Produce"],
        "cold_storage_capacity_kg": 450.0,
        "current_available_capacity_kg": 380.0,
        "refrigeration_guaranteed": True,
        "contact_phone": "+1-510-555-0811",
        "compliance_verified": True,
        "coordinator_name": "Sarah Lin (Student Volunteer Lead)"
    },
    {
        "recipient_id": "NGO-HOPE-SHELTER",
        "name": "Hope Community Kitchen & Shelter",
        "address": "1931 Center St, Berkeley, CA",
        "distance_km": 1.4,
        "transit_time_minutes": 12,
        "accepts_categories": ["Prepared Meals", "Proteins", "Perishable Dairy", "Fresh Produce"],
        "cold_storage_capacity_kg": 800.0,
        "current_available_capacity_kg": 620.0,
        "refrigeration_guaranteed": True,
        "contact_phone": "+1-510-555-0199",
        "compliance_verified": True,
        "coordinator_name": "Father Thomas Bradley"
    },
    {
        "recipient_id": "RECIP-EASTBAY-01",
        "name": "Alameda County Community Food Bank",
        "address": "7900 Edgewater Dr, Oakland, CA",
        "distance_km": 11.2,
        "transit_time_minutes": 22,
        "accepts_categories": ["Perishable Dairy", "Fresh Produce", "Proteins"],
        "cold_storage_capacity_kg": 3500.0,
        "current_available_capacity_kg": 2100.0,
        "refrigeration_guaranteed": True,
        "contact_phone": "+1-510-635-3663",
        "compliance_verified": True
    },
    {
        "recipient_id": "RECIP-SFRES-02",
        "name": "Glide Memorial Sustenance Pantry",
        "address": "330 Ellis St, San Francisco, CA",
        "distance_km": 24.5,
        "transit_time_minutes": 38,
        "accepts_categories": ["Fresh Produce", "Perishable Dairy"],
        "cold_storage_capacity_kg": 1200.0,
        "current_available_capacity_kg": 950.0,
        "refrigeration_guaranteed": True,
        "contact_phone": "+1-415-674-6000",
        "compliance_verified": True
    },
    {
        "recipient_id": "RECIP-VALLEY-03",
        "name": "Second Harvest Silicon Valley",
        "address": "4001 N 1st St, San Jose, CA",
        "distance_km": 42.0,
        "transit_time_minutes": 50,
        "accepts_categories": ["Perishable Dairy", "Fresh Produce", "Proteins"],
        "cold_storage_capacity_kg": 5000.0,
        "current_available_capacity_kg": 3200.0,
        "refrigeration_guaranteed": True,
        "contact_phone": "+1-408-266-8866",
        "compliance_verified": True
    }
]

SAMPLE_LOGISTICS_CARRIERS: List[Dict[str, Any]] = [
    {
        "carrier_id": "CARRIER-COLD-90",
        "name": "EverFrost CleanFleet Logistics",
        "vehicle_type": "Refrigerated Sprinter Van (Tier 4 Electric)",
        "capacity_kg": 1800.0,
        "active_temp_control": True,
        "temp_range_c": [-20.0, 5.0],
        "base_rate_usd": 120.0,
        "per_km_rate_usd": 2.50,
        "available_immediate": True,
        "driver_id": "DRV-MARCOS-88"
    },
    {
        "carrier_id": "CARRIER-SWIFT-14",
        "name": "EcoFreight Reefer Express",
        "vehicle_type": "Chilled Box Truck 24ft",
        "capacity_kg": 4500.0,
        "active_temp_control": True,
        "temp_range_c": [-25.0, 10.0],
        "base_rate_usd": 220.0,
        "per_km_rate_usd": 3.10,
        "available_immediate": True,
        "driver_id": "DRV-CHEN-42"
    }
]
