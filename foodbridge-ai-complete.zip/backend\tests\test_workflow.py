import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.models.schemas import WorkflowStatus, StepStatus

client = TestClient(app)

def test_full_agentic_workflow_with_human_approvals():
    # 1. Create Incident
    payload = {
        "title": "Pacific Cold Storage Dairy Surplus",
        "description": "Urgent surplus: 1420 kg organic yogurt at risk of expiration in 36 hours. Route to food bank.",
        "warehouse_id": "WH-WEST-01",
        "inventory_batch_id": "BATCH-DAIRY-802",
        "max_budget_usd": 350.0,
        "max_transit_hours": 4.0,
        "require_refrigeration": True
    }
    create_res = client.post("/api/incidents", json=payload)
    assert create_res.status_code == 200
    wf = create_res.json()
    wf_id = wf["workflow_id"]
    assert len(wf["plan"]["steps"]) == 7

    # 2. Advance Step 1 (Inspect Telemetry - Safe Autonomous)
    adv1 = client.post(f"/api/workflows/{wf_id}/advance")
    assert adv1.status_code == 200
    assert adv1.json()["plan"]["steps"][0]["status"] == "SUCCEEDED"
    assert adv1.json()["plan"]["steps"][0]["verification_passed"] is True

    # 3. Advance Step 2 (Match Recipient - Safe Autonomous)
    adv2 = client.post(f"/api/workflows/{wf_id}/advance")
    assert adv2.status_code == 200
    assert adv2.json()["plan"]["steps"][1]["status"] == "SUCCEEDED"

    # 4. Advance Step 3 (Freight Booking - Sensitive) -> Must halt at Approval Gate
    adv3 = client.post(f"/api/workflows/{wf_id}/advance")
    assert adv3.status_code == 200
    res3 = adv3.json()
    assert res3["status"] == "AWAITING_APPROVAL"
    assert res3["plan"]["steps"][2]["status"] == "AWAITING_APPROVAL"

    # 5. Dispatcher Approves Step 3
    appr1 = client.post(
        f"/api/workflows/{wf_id}/approve",
        json={
            "step_id": "step-3-reserve-freight",
            "decision": "APPROVE",
            "decided_by": "Dispatcher-Jane",
            "reason": "Reefer vehicle budget and specs confirmed acceptable."
        }
    )
    assert appr1.status_code == 200
    assert appr1.json()["plan"]["steps"][2]["status"] == "APPROVED"

    # 6. Advance Step 3 (Now approved -> Executes tool)
    adv3_exec = client.post(f"/api/workflows/{wf_id}/advance")
    assert adv3_exec.status_code == 200
    assert adv3_exec.json()["plan"]["steps"][2]["status"] == "SUCCEEDED"

    # 7. Advance Step 4 (Dispatch Manifest - Sensitive) -> Must halt at Approval Gate
    adv4 = client.post(f"/api/workflows/{wf_id}/advance")
    assert adv4.status_code == 200
    assert adv4.json()["status"] == "AWAITING_APPROVAL"

    # 8. Dispatcher Approves Step 4
    appr2 = client.post(
        f"/api/workflows/{wf_id}/approve",
        json={
            "step_id": "step-4-dispatch-manifest",
            "decision": "APPROVE",
            "decided_by": "Dispatcher-Jane",
            "reason": "Custody transfer to Alameda Food Bank approved."
        }
    )
    assert appr2.status_code == 200

    # 9. Execute remaining steps automatically to completion
    auto_res = client.post(f"/api/workflows/{wf_id}/auto-execute")
    assert auto_res.status_code == 200
    final_wf = auto_res.json()
    assert final_wf["status"] == "COMPLETED"
    assert final_wf["current_step_index"] == 7

def test_human_rejection_halts_and_cancels():
    payload = {
        "title": "Surplus Rejection Test",
        "description": "Testing human rejection safety abort mechanism.",
        "warehouse_id": "WH-WEST-01",
        "inventory_batch_id": "BATCH-BERRY-415"
    }
    wf = client.post("/api/incidents", json=payload).json()
    wf_id = wf["workflow_id"]

    # Advance through safe steps
    client.post(f"/api/workflows/{wf_id}/advance")
    client.post(f"/api/workflows/{wf_id}/advance")
    
    # Hits freight approval
    client.post(f"/api/workflows/{wf_id}/advance")

    # Reject step
    reject_res = client.post(
        f"/api/workflows/{wf_id}/approve",
        json={
            "step_id": "step-3-reserve-freight",
            "decision": "REJECT",
            "decided_by": "Supervisor-Dave",
            "reason": "Carrier quotation excessive; aborting allocation."
        }
    )
    assert reject_res.status_code == 200
    cancelled_wf = reject_res.json()
    assert cancelled_wf["status"] == "CANCELLED"
    assert "rejected by" in cancelled_wf["error_message"]

def test_auto_execute_bounded_at_gate():
    payload = {
        "title": "Batch Auto Execute Test",
        "description": "Testing bounded execution stopping cleanly at approval gate.",
        "warehouse_id": "WH-WEST-01",
        "inventory_batch_id": "BATCH-BERRY-415"
    }
    wf = client.post("/api/incidents", json=payload).json()
    wf_id = wf["workflow_id"]

    # auto-execute should run steps 1 and 2, then pause safely at step 3
    res = client.post(f"/api/workflows/{wf_id}/auto-execute")
    assert res.status_code == 200
    data = res.json()
    assert data["status"] == "AWAITING_APPROVAL"
    assert data["current_step_index"] == 2
