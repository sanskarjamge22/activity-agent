import uuid
from typing import Dict, Any, List
from app.tools.registry import tool_registry
from app.models.schemas import ToolSensitivity
from app.data.sample_data import (
    SAMPLE_DONORS,
    SAMPLE_WAREHOUSES,
    SAMPLE_INVENTORIES,
    SAMPLE_RECIPIENTS,
    SAMPLE_LOGISTICS_CARRIERS
)

@tool_registry.register(
    name="inspect_inventory_telemetry",
    description="Inspects real-time IoT temperature sensor logs, batch shelf life, and spoilage risk.",
    sensitivity=ToolSensitivity.SAFE_AUTONOMOUS,
    schema_params={"warehouse_id": "string", "batch_id": "string"}
)
def inspect_inventory_telemetry(warehouse_id: str, batch_id: str) -> Dict[str, Any]:
    warehouse = SAMPLE_WAREHOUSES.get(warehouse_id) or SAMPLE_DONORS.get(warehouse_id)
    if not warehouse:
        warehouse = {
            "id": warehouse_id,
            "name": warehouse_id,
            "location": "Berkeley, CA",
            "telemetry_health": "ONLINE"
        }
    
    batch = SAMPLE_INVENTORIES.get(batch_id)
    if not batch:
        # Generate dynamic record if custom batch requested
        batch = {
            "batch_id": batch_id,
            "warehouse_id": warehouse_id,
            "commodity": "Mixed Chilled Produce & Dairy",
            "category": "Perishable Dairy",
            "quantity_kg": 1200.0,
            "est_retail_value_usd": 5400.0,
            "current_temp_c": 3.2,
            "min_safe_temp_c": 1.0,
            "max_safe_temp_c": 4.5,
            "shelf_life_remaining_hours": 30.0,
            "status": "AT_RISK_EXPIRY",
            "co2e_per_kg": 2.5,
            "meals_multiplier": 2.0
        }

    is_temp_safe = batch["min_safe_temp_c"] <= batch["current_temp_c"] <= batch["max_safe_temp_c"]
    spoilage_risk_score = 0.85 if batch["shelf_life_remaining_hours"] <= 24 else 0.65

    return {
        "status": "SUCCESS",
        "warehouse_location": warehouse["location"],
        "batch_id": batch["batch_id"],
        "commodity": batch["commodity"],
        "category": batch["category"],
        "quantity_kg": batch["quantity_kg"],
        "current_temperature_c": batch["current_temp_c"],
        "temperature_within_safe_limits": is_temp_safe,
        "hours_until_spoilage": batch["shelf_life_remaining_hours"],
        "spoilage_risk_score": spoilage_risk_score,
        "recommendation": "IMMEDIATE_REDISTRIBUTION_RECOMMENDED"
    }

@tool_registry.register(
    name="match_recipient_network",
    description="Queries verified food bank recipient network by storage capacity, distance, and dietary capabilities.",
    sensitivity=ToolSensitivity.SAFE_AUTONOMOUS,
    schema_params={"commodity_category": "string", "required_capacity_kg": "float", "max_distance_km": "float"}
)
def match_recipient_network(
    commodity_category: str,
    required_capacity_kg: float,
    max_distance_km: float = 50.0
) -> Dict[str, Any]:
    matched = []
    for r in SAMPLE_RECIPIENTS:
        if r["distance_km"] <= max_distance_km and r["current_available_capacity_kg"] >= required_capacity_kg:
            matched.append(r)
            
    if not matched:
        # Fallback to closest available with partial or adjusted capacity
        matched = sorted(SAMPLE_RECIPIENTS, key=lambda x: x["distance_km"])[:2]

    # Rank by best fit (lowest distance + highest capacity)
    best_candidate = matched[0]
    return {
        "status": "SUCCESS",
        "total_matched_recipients": len(matched),
        "selected_best_recipient": best_candidate,
        "all_eligible_candidates": matched
    }

@tool_registry.register(
    name="notify_ngo_coordinator",
    description="Sends external dispatch alert (SMS/Push Notification) to designated NGO coordinator. Requires human verification before message dispatch.",
    sensitivity=ToolSensitivity.SENSITIVE_REQUIRES_APPROVAL,
    schema_params={
        "recipient_id": "string",
        "listing_id": "string",
        "pickup_window": "string",
        "message_channel": "string"
    }
)
def notify_ngo_coordinator(
    recipient_id: str,
    listing_id: str,
    pickup_window: str = "Within 90 minutes",
    message_channel: str = "SMS"
) -> Dict[str, Any]:
    recipient = next((r for r in SAMPLE_RECIPIENTS if r["recipient_id"] == recipient_id), SAMPLE_RECIPIENTS[0])
    msg_id = f"MSG-ALERT-{uuid.uuid4().hex[:8].upper()}"
    
    return {
        "status": "MESSAGE_DISPATCHED",
        "message_id": msg_id,
        "recipient_name": recipient["name"],
        "channel": message_channel,
        "contact_phone": recipient.get("contact_phone", "+1-510-555-0811"),
        "pickup_window": pickup_window,
        "payload_delivered": True,
        "content_preview": f"FoodBridge Rescue Alert: Surplus ready for pickup at {pickup_window}."
    }

@tool_registry.register(
    name="confirm_donation_reservation",
    description="Officially confirms food donation allocation and reserves inventory. Requires human approval gate.",
    sensitivity=ToolSensitivity.SENSITIVE_REQUIRES_APPROVAL,
    schema_params={
        "listing_id": "string",
        "recipient_id": "string",
        "servings": "integer"
    }
)
def confirm_donation_reservation(
    listing_id: str,
    recipient_id: str,
    servings: int = 50
) -> Dict[str, Any]:
    reservation_id = f"RES-DONATION-{uuid.uuid4().hex[:8].upper()}"
    recipient = next((r for r in SAMPLE_RECIPIENTS if r["recipient_id"] == recipient_id), SAMPLE_RECIPIENTS[0])

    return {
        "status": "DONATION_CONFIRMED",
        "reservation_id": reservation_id,
        "listing_id": listing_id,
        "recipient_name": recipient["name"],
        "allocated_servings": servings,
        "hold_duration_hours": 3.0,
        "legal_good_samaritan_protection_applied": True
    }

@tool_registry.register(
    name="reserve_cold_freight",
    description="Books and locks an active refrigerated commercial vehicle for temperature-controlled transport.",
    sensitivity=ToolSensitivity.SENSITIVE_REQUIRES_APPROVAL,
    schema_params={
        "carrier_id": "string",
        "pickup_location": "string",
        "delivery_location": "string",
        "weight_kg": "float"
    }
)
def reserve_cold_freight(
    carrier_id: str,
    pickup_location: str,
    delivery_location: str,
    weight_kg: float
) -> Dict[str, Any]:
    carrier = next((c for c in SAMPLE_LOGISTICS_CARRIERS if c["carrier_id"] == carrier_id), SAMPLE_LOGISTICS_CARRIERS[0])
    
    # Calculate estimated freight cost
    est_distance_km = 22.0
    cost_usd = carrier["base_rate_usd"] + (carrier["per_km_rate_usd"] * est_distance_km)
    booking_ref = f"BK-FRG-{uuid.uuid4().hex[:8].upper()}"

    return {
        "status": "BOOKED",
        "booking_reference": booking_ref,
        "carrier_name": carrier["name"],
        "vehicle_type": carrier["vehicle_type"],
        "driver_id": carrier["driver_id"],
        "total_cost_usd": round(cost_usd, 2),
        "pickup": pickup_location,
        "delivery": delivery_location,
        "allocated_payload_kg": weight_kg,
        "reefer_telemetry_stream": f"mqtt://fleet.everfrost.internal/streams/{booking_ref}"
    }

@tool_registry.register(
    name="dispatch_transfer_manifest",
    description="Issues legally binding transfer manifest, updates donor warehouse balance, and generates bill of lading.",
    sensitivity=ToolSensitivity.SENSITIVE_REQUIRES_APPROVAL,
    schema_params={
        "batch_id": "string",
        "recipient_id": "string",
        "carrier_id": "string",
        "booking_ref": "string"
    }
)
def dispatch_transfer_manifest(
    batch_id: str,
    recipient_id: str,
    carrier_id: str,
    booking_ref: str
) -> Dict[str, Any]:
    manifest_id = f"MNF-{uuid.uuid4().hex[:8].upper()}"
    tracking_barcode = f"TRK-{uuid.uuid4().hex[:10].upper()}"

    return {
        "status": "DISPATCHED",
        "manifest_id": manifest_id,
        "tracking_barcode": tracking_barcode,
        "batch_id": batch_id,
        "recipient_id": recipient_id,
        "carrier_id": carrier_id,
        "booking_ref": booking_ref,
        "custody_state": "IN_TRANSIT",
        "dispatch_timestamp": "2026-10-23T12:00:00Z"
    }

@tool_registry.register(
    name="verify_temperature_integrity",
    description="Mathematical verification tool: cross-checks GPS & cold-chain sensor records during transport against regulatory limits.",
    sensitivity=ToolSensitivity.SAFE_AUTONOMOUS,
    schema_params={"manifest_id": "string", "min_temp_c": "float", "max_temp_c": "float"}
)
def verify_temperature_integrity(
    manifest_id: str,
    min_temp_c: float = 1.0,
    max_temp_c: float = 4.5
) -> Dict[str, Any]:
    # Simulated IoT sensor data recorded during 30 min transit
    simulated_logged_temperatures = [2.9, 3.1, 3.2, 3.0, 3.4, 3.3, 3.1]
    all_within_threshold = all(min_temp_c <= t <= max_temp_c for t in simulated_logged_temperatures)
    
    return {
        "status": "VERIFIED_COMPLIANT" if all_within_threshold else "EXCURSION_DETECTED",
        "manifest_id": manifest_id,
        "samples_evaluated": len(simulated_logged_temperatures),
        "mean_temp_c": round(sum(simulated_logged_temperatures) / len(simulated_logged_temperatures), 2),
        "max_recorded_temp_c": max(simulated_logged_temperatures),
        "min_recorded_temp_c": min(simulated_logged_temperatures),
        "cold_chain_breach": not all_within_threshold,
        "haccp_compliant": all_within_threshold
    }

@tool_registry.register(
    name="finalize_chain_of_custody",
    description="Records recipient electronic signature, releases donor liability, and completes donation handover.",
    sensitivity=ToolSensitivity.SAFE_AUTONOMOUS,
    schema_params={"manifest_id": "string", "recipient_id": "string", "signature_token": "string"}
)
def finalize_chain_of_custody(
    manifest_id: str,
    recipient_id: str,
    signature_token: str = "SIG-RECEIPT-VERIFIED"
) -> Dict[str, Any]:
    return {
        "status": "COMPLETED",
        "manifest_id": manifest_id,
        "recipient_id": recipient_id,
        "delivery_confirmed": True,
        "electronic_receipt_hash": f"SHA256-{uuid.uuid4().hex}",
        "chain_of_custody_closed": True
    }

@tool_registry.register(
    name="calculate_impact_accounting",
    description="Calculates objective environmental, social, and economic impact metrics from verified rescue.",
    sensitivity=ToolSensitivity.SAFE_AUTONOMOUS,
    schema_params={"batch_id": "string", "rescued_kg": "float"}
)
def calculate_impact_accounting(batch_id: str, rescued_kg: float) -> Dict[str, Any]:
    batch = SAMPLE_INVENTORIES.get(batch_id, {})
    co2_factor = batch.get("co2e_per_kg", 2.2)
    meals_factor = batch.get("meals_multiplier", 2.0)
    
    co2_averted = rescued_kg * co2_factor
    meals_provided = int(rescued_kg * meals_factor)
    est_value_saved = rescued_kg * 4.50

    return {
        "status": "SUCCESS",
        "food_rescued_kg": rescued_kg,
        "meals_provided": meals_provided,
        "co2e_averted_kg": round(co2_averted, 2),
        "financial_value_preserved_usd": round(est_value_saved, 2),
        "landfill_diversion_rate": 100.0
    }
