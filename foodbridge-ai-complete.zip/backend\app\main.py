from fastapi import FastAPI, HTTPException, Header, Depends, Query, status
from fastapi.middleware.cors import CORSMiddleware
from typing import Optional, List, Dict, Any

from app.config import settings
from app.models.schemas import (
    CreateIncidentRequest,
    ApprovalDecisionRequest,
    UpdateListingStatusRequest,
    MatchRecipientRequest,
    TemperatureValidationRequest,
    ImpactCalculationRequest,
    WorkflowExecution,
    SystemMetrics,
    AuditLogEntry,
    SecuritySettingsDTO,
    UserRole
)
from app.models.database import db
from app.core.security import (
    SecurityManager,
    get_current_user,
    require_role
)
from app.core.audit import audit_manager
from app.core.state_machine import state_machine
from app.tools.registry import tool_registry
# Ensure rescue tools are registered
import app.tools.rescue_tools
from app.data.sample_data import (
    SAMPLE_DONORS,
    SAMPLE_WAREHOUSES,
    SAMPLE_INVENTORIES,
    SAMPLE_RECIPIENTS,
    SAMPLE_LOGISTICS_CARRIERS
)

app = FastAPI(
    title="ActiVity AI — Autonomous Action Intelligence",
    description="Agentic AI platform for autonomous reasoning, planning, tool use, human approval gating, and verifiable real-world execution.",
    version=settings.APP_VERSION
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/health")
def health_check():
    return {
        "status": "HEALTHY",
        "service": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "model": settings.GEMINI_MODEL,
        "demo_mode": settings.DEMO_MODE,
        "registered_tools": len(tool_registry.get_allowlist()),
        "prompt_injection_defense": settings.ENABLE_PROMPT_INJECTION_DEFENSE
    }

@app.get("/api/metrics", response_model=SystemMetrics)
def get_metrics():
    return db.compute_metrics()

@app.get("/api/sample-data")
def get_sample_data():
    return {
        "donors": list(SAMPLE_DONORS.values()),
        "warehouses": list(SAMPLE_WAREHOUSES.values()),
        "inventories": list(SAMPLE_INVENTORIES.values()),
        "recipients": SAMPLE_RECIPIENTS,
        "carriers": SAMPLE_LOGISTICS_CARRIERS
    }

@app.get("/api/donors")
def get_donors():
    return list(SAMPLE_DONORS.values())

@app.get("/api/recipients")
def get_recipients():
    return db.list_recipients()

@app.get("/api/tools")
def get_tools():
    defs = tool_registry.get_definitions()
    return [
        {
            "name": d.name,
            "description": d.description,
            "sensitivity": d.sensitivity.value,
            "schema_params": d.schema_params
        }
        for d in defs.values()
    ]

@app.post("/api/listings", response_model=WorkflowExecution)
@app.post("/api/incidents", response_model=WorkflowExecution)
async def create_listing(
    request: CreateIncidentRequest,
    idempotency_key: Optional[str] = Header(None, alias="Idempotency-Key"),
    current_user: Dict[str, Any] = Depends(require_role([UserRole.ADMIN, UserRole.DISPATCHER, UserRole.CANTEEN_STAFF]))
):
    # Idempotency check
    SecurityManager.check_idempotency(idempotency_key)
    
    # Prompt injection and input sanitization
    sanitized_desc = SecurityManager.sanitize_text(request.description)
    sanitized_notes = SecurityManager.sanitize_text(request.notes or "")
    request.description = sanitized_desc
    request.notes = sanitized_notes

    workflow = await state_machine.create_and_plan_workflow(
        request=request,
        actor=f"{current_user['role'].value.upper()}:{current_user['user_id']}"
    )
    return workflow

@app.get("/api/listings")
def get_all_listings():
    """Returns all surplus food listings stored in the persistent SQLite database."""
    return db.list_listings()

@app.get("/api/listings/{listing_id}")
def get_single_listing(listing_id: str):
    """Retrieves a single surplus food listing by its ID."""
    listing = db.get_listing(listing_id)
    if not listing:
        raise HTTPException(status_code=404, detail=f"Listing '{listing_id}' not found")
    return listing

@app.patch("/api/listings/{listing_id}")
def update_listing_status(
    listing_id: str,
    update_req: UpdateListingStatusRequest,
    current_user: Dict[str, Any] = Depends(require_role([UserRole.ADMIN, UserRole.DISPATCHER, UserRole.CANTEEN_STAFF]))
):
    """Updates listing status (AVAILABLE, RESERVED, PICKED_UP, CANCELLED)."""
    listing = db.get_listing(listing_id)
    if not listing:
        raise HTTPException(status_code=404, detail=f"Listing '{listing_id}' not found")
    db.update_listing_status(listing_id, update_req.status, update_req.notes)
    return {"status": "SUCCESS", "listing_id": listing_id, "new_status": update_req.status}

@app.post("/api/recipients/match")
def match_recipients(req: MatchRecipientRequest):
    """Ranks and returns verified community NGOs by distance, capacity, and dietary capabilities."""
    all_recipients = db.list_recipients()
    
    # Filter candidates
    matched = []
    for r in all_recipients:
        # Check distance threshold
        if r["distance_km"] <= req.max_distance_km:
            # Check capacity
            has_capacity = r["current_available_capacity_kg"] >= req.weight_kg
            # Check refrigeration if required
            reefer_ok = True if not req.require_refrigeration else r["refrigeration_guaranteed"]
            
            score = 100.0 - (r["distance_km"] * 1.5)
            if has_capacity:
                score += 30.0
            if reefer_ok:
                score += 20.0

            matched.append({
                "recipient": r,
                "match_score": round(score, 1),
                "has_capacity": has_capacity,
                "refrigeration_suitable": reefer_ok,
                "recommendation_reason": f"{r['name']} is {r['distance_km']} km away with {r['current_available_capacity_kg']} kg capacity."
            })

    matched.sort(key=lambda x: x["match_score"], reverse=True)
    return {
        "total_matched": len(matched),
        "best_match": matched[0] if matched else None,
        "all_matches": matched
    }

@app.post("/api/safety/validate-temperature")
def validate_temperature(req: TemperatureValidationRequest):
    """Validates food safety & cold-chain temperature against HACCP regulatory envelopes."""
    temp = req.temperature_c
    cat = req.food_category.upper()
    
    # Food safety criteria:
    # 1. Chilled / Dairy / Produce: 0.5C to 4.5C is safe
    # 2. Hot Prepared: >= 60.0C is safe warm holding; if chilled, must be <= 4.0C
    # 3. Danger Zone: 5.0C to 59.0C
    if "HOT" in cat or "PREPARED" in cat:
        if temp >= 60.0:
            return {
                "is_safe": True,
                "haccp_compliant": True,
                "temperature_c": temp,
                "safe_range": ">= 60.0°C (Hot Holding)",
                "status": "SAFE_WARM_HOLDING",
                "action_recommended": "Maintain insulated warmer during transport; deliver within 2 hours."
            }
        elif temp <= 4.0:
            return {
                "is_safe": True,
                "haccp_compliant": True,
                "temperature_c": temp,
                "safe_range": "<= 4.0°C (Rapid Chilled)",
                "status": "SAFE_CHILLED",
                "action_recommended": "Maintain cold chain under refrigeration."
            }
        else:
            return {
                "is_safe": False,
                "haccp_compliant": False,
                "temperature_c": temp,
                "safe_range": ">= 60.0°C or <= 4.0°C",
                "status": "DANGER_ZONE_VIOLATION",
                "action_recommended": "CRITICAL: Food is in temperature danger zone (5°C-59°C). Reheat to >74°C or discard."
            }
    else:
        # Standard perishable cold chain
        is_safe = 0.5 <= temp <= 4.5
        return {
            "is_safe": is_safe,
            "haccp_compliant": is_safe,
            "temperature_c": temp,
            "safe_range": "0.5°C to 4.5°C",
            "status": "COMPLIANT" if is_safe else "EXCURSION_DETECTED",
            "action_recommended": "Safe for transit." if is_safe else "Temperature excursion: check reefer sensor."
        }

@app.post("/api/analytics/calculate-impact")
def calculate_impact(req: ImpactCalculationRequest):
    """Calculates objective meals rescued, CO2e averted, and economic value preserved."""
    wt = req.weight_kg
    cat = req.food_category.upper()
    
    # Emission factor (kg CO2e per kg food saved) from EPA WARM v15
    factors = {
        "PREPARED_HOT_MEALS": 2.5,
        "FRESH_BAKERY": 1.8,
        "CHILLED_DAIRY": 2.8,
        "FRESH_PRODUCE": 1.4,
        "PACKAGED_GOODS": 2.0
    }
    co2_factor = factors.get(cat, 2.2)
    
    meals = round(wt * 2.2)
    co2e = round(wt * co2_factor, 2)
    val = round(wt * 4.50, 2)
    water_liters = round(wt * 350)

    return {
        "weight_kg": wt,
        "meals_rescued": meals,
        "co2e_averted_kg": co2e,
        "financial_value_usd": val,
        "water_conserved_liters": water_liters,
        "landfill_diversion_rate": 100.0
    }

@app.get("/api/workflows", response_model=List[WorkflowExecution])
def list_workflows():
    return db.list_workflows()

@app.get("/api/workflows/{workflow_id}", response_model=WorkflowExecution)
def get_workflow(workflow_id: str):
    wf = db.get_workflow(workflow_id)
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")
    return wf

@app.post("/api/workflows/{workflow_id}/advance", response_model=WorkflowExecution)
async def advance_step(
    workflow_id: str,
    current_user: Dict[str, Any] = Depends(require_role([UserRole.ADMIN, UserRole.DISPATCHER]))
):
    return await state_machine.advance_workflow(workflow_id)

@app.post("/api/workflows/{workflow_id}/auto-execute", response_model=WorkflowExecution)
async def auto_execute(
    workflow_id: str,
    current_user: Dict[str, Any] = Depends(require_role([UserRole.ADMIN, UserRole.DISPATCHER]))
):
    """Executes permitted steps automatically until completion or an Approval Gate is reached."""
    wf = db.get_workflow(workflow_id)
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")
        
    for _ in range(10):  # Bounded iteration safety guard
        if wf.status in ("AWAITING_APPROVAL", "COMPLETED", "FAILED", "CANCELLED"):
            break
        wf = await state_machine.advance_workflow(workflow_id)

    return wf

@app.post("/api/workflows/{workflow_id}/approve", response_model=WorkflowExecution)
def submit_approval(
    workflow_id: str,
    decision_req: ApprovalDecisionRequest,
    current_user: Dict[str, Any] = Depends(require_role([UserRole.ADMIN, UserRole.DISPATCHER]))
):
    return state_machine.process_approval_decision(
        workflow_id=workflow_id,
        step_id=decision_req.step_id,
        decision=decision_req.decision,
        decided_by=f"{current_user['role'].value.upper()}:{decision_req.decided_by}",
        reason=decision_req.reason
    )

@app.get("/api/audit-logs", response_model=List[AuditLogEntry])
def get_audit_logs(workflow_id: Optional[str] = Query(None)):
    return audit_manager.get_entries(workflow_id=workflow_id)

@app.get("/api/audit-logs/verify")
def verify_audit_integrity():
    return audit_manager.verify_chain_integrity()

@app.get("/api/settings", response_model=SecuritySettingsDTO)
def get_security_settings(current_user: Dict[str, Any] = Depends(get_current_user)):
    return SecuritySettingsDTO(
        prompt_injection_defense=settings.ENABLE_PROMPT_INJECTION_DEFENSE,
        autonomous_safe_tools=True,
        max_budget_limit=settings.MAX_ALLOWABLE_BUDGET_USD,
        allowed_tools_count=len(tool_registry.get_allowlist()),
        active_role=current_user["role"],
        demo_mode=settings.DEMO_MODE
    )

@app.post("/api/settings")
def update_security_settings(
    dto: SecuritySettingsDTO,
    current_user: Dict[str, Any] = Depends(require_role([UserRole.ADMIN]))
):
    settings.ENABLE_PROMPT_INJECTION_DEFENSE = dto.prompt_injection_defense
    return {"status": "SUCCESS", "message": "Security policy configuration updated."}

from pathlib import Path
from fastapi.staticfiles import StaticFiles

# Mount React UI production bundle if present
frontend_dist = Path(__file__).resolve().parent.parent.parent / "frontend" / "dist"
if frontend_dist.exists():
    app.mount("/", StaticFiles(directory=str(frontend_dist), html=True), name="frontend")
