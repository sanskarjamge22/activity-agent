from typing import Dict, Any
from app.data.sample_data import SAMPLE_WAREHOUSES, SAMPLE_INVENTORIES

class DataAnalysisAgent:
    def analyze_incident(
        self,
        warehouse_id: str,
        inventory_batch_id: str,
        max_transit_hours: float
    ) -> Dict[str, Any]:
        """Analyzes sensor logs, shelf life, and anomaly risks for the given batch."""
        batch = SAMPLE_INVENTORIES.get(inventory_batch_id)
        warehouse = SAMPLE_WAREHOUSES.get(warehouse_id)
        
        if not batch:
            # Synthetic default analysis
            return {
                "spoilage_urgency": "HIGH",
                "urgency_score": 0.88,
                "shelf_life_hours": 30.0,
                "temp_stability": "NOMINAL",
                "risk_factors": ["Perishable batch approaching critical expiry window."],
                "recommended_action": "AUTONOMOUS_INTERVENTION_REQUIRED"
            }
        
        hours = batch["shelf_life_remaining_hours"]
        urgency = "CRITICAL" if hours <= 24 else ("HIGH" if hours <= 48 else "MODERATE")
        urgency_score = max(0.1, min(1.0, 1.0 - (hours / 72.0)))
        
        risk_factors = []
        if hours < max_transit_hours * 3:
            risk_factors.append("Tight transit window relative to remaining shelf life.")
        if batch["current_temp_c"] > batch["max_safe_temp_c"] * 0.9:
            risk_factors.append("Temperature approaching upper critical threshold limit.")

        return {
            "warehouse_name": warehouse["name"] if warehouse else warehouse_id,
            "commodity": batch["commodity"],
            "quantity_kg": batch["quantity_kg"],
            "shelf_life_hours": hours,
            "current_temp_c": batch["current_temp_c"],
            "spoilage_urgency": urgency,
            "urgency_score": round(urgency_score, 2),
            "temp_stability": "NOMINAL",
            "risk_factors": risk_factors or ["Standard cold-chain expiration countdown."],
            "recommended_action": "REDISTRIBUTE_TO_FOOD_BANK"
        }

analyst_agent = DataAnalysisAgent()
