import React from 'react';
import { 
  GitMerge, 
  CheckCircle2, 
  Clock, 
  ShieldAlert, 
  Play, 
  FastForward, 
  AlertTriangle, 
  FileText, 
  Lock, 
  Sparkles,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import { WorkflowExecution, PlanStep, UserRole } from '../types';

interface PlanVisualizerViewProps {
  workflow: WorkflowExecution | null;
  onAdvanceStep: () => Promise<void>;
  onAutoExecute: () => Promise<void>;
  onOpenApprovalModal: (step: PlanStep) => void;
  userRole: UserRole;
  isActionLoading: boolean;
}

export const PlanVisualizerView: React.FC<PlanVisualizerViewProps> = ({
  workflow,
  onAdvanceStep,
  onAutoExecute,
  onOpenApprovalModal,
  userRole,
  isActionLoading
}) => {
  if (!workflow || !workflow.plan) {
    return (
      <div className="glass-panel" style={{ padding: '3rem', textAlign: 'center' }}>
        <GitMerge size={48} color="#94a3b8" style={{ margin: '0 auto 1rem auto' }} />
        <h3 style={{ fontSize: '1.25rem', fontWeight: 700, color: '#f8fafc', marginBottom: '0.5rem' }}>
          No Active Plan Selected
        </h3>
        <p style={{ color: '#94a3b8', fontSize: '0.9rem', maxWidth: '400px', margin: '0 auto' }}>
          Select an ongoing rescue operation from the Dashboard or create a new surplus food listing.
        </p>
      </div>
    );
  }

  const { plan, status, current_step_index } = workflow;
  const currentStep = plan.steps[current_step_index];
  const isAwaitingApproval = status === 'AWAITING_APPROVAL' || currentStep?.status === 'AWAITING_APPROVAL';

  const getStepStatusBadge = (s: PlanStep['status'], sensitivity: PlanStep['sensitivity']) => {
    switch (s) {
      case 'SUCCEEDED':
        return <span className="badge badge-success"><CheckCircle2 size={12} /> Succeeded</span>;
      case 'RUNNING':
        return <span className="badge badge-info"><Clock size={12} /> Executing</span>;
      case 'AWAITING_APPROVAL':
        return <span className="badge badge-warning pulse-amber"><ShieldAlert size={12} /> Approval Required</span>;
      case 'APPROVED':
        return <span className="badge badge-cyan"><CheckCircle2 size={12} /> Authorized</span>;
      case 'FAILED':
        return <span className="badge badge-danger"><AlertTriangle size={12} /> Failed</span>;
      case 'REJECTED':
        return <span className="badge badge-danger">Rejected</span>;
      default:
        return sensitivity === 'SENSITIVE_REQUIRES_APPROVAL'
          ? <span className="badge badge-warning" style={{ opacity: 0.75 }}><Lock size={12} /> Sensitive Gate</span>
          : <span className="badge" style={{ background: 'rgba(255,255,255,0.06)', color: '#94a3b8' }}>Planned</span>;
    }
  };

  return (
    <div>
      {/* Workflow Header & Rationale */}
      <div className="glass-panel" style={{ padding: '1.75rem', marginBottom: '1.5rem', border: isAwaitingApproval ? '1px solid rgba(245, 158, 11, 0.4)' : undefined }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem', marginBottom: '1rem' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem' }}>
              <span className="badge badge-cyan">{workflow.workflow_id}</span>
              <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Created {new Date(workflow.created_at).toLocaleTimeString()}</span>
            </div>
            <h2 style={{ fontSize: '1.4rem', fontWeight: 800, color: '#f8fafc' }}>
              {workflow.title}
            </h2>
          </div>

          {/* Action Control Buttons */}
          <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
            {status !== 'COMPLETED' && status !== 'CANCELLED' && (
              <>
                {isAwaitingApproval ? (
                  <button
                    className="btn-primary"
                    style={{ background: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)', boxShadow: '0 4px 14px rgba(245, 158, 11, 0.4)' }}
                    onClick={() => onOpenApprovalModal(currentStep)}
                  >
                    <ShieldAlert size={18} />
                    <span>Review Approval Gate</span>
                  </button>
                ) : (
                  <>
                    <button
                      className="btn-primary"
                      onClick={onAdvanceStep}
                      disabled={isActionLoading}
                    >
                      <Play size={16} />
                      <span>{isActionLoading ? 'Running...' : 'Advance Step'}</span>
                    </button>
                    <button
                      className="btn-secondary"
                      onClick={onAutoExecute}
                      disabled={isActionLoading}
                    >
                      <FastForward size={16} />
                      <span>Auto-Execute Permitted</span>
                    </button>
                  </>
                )}
              </>
            )}
            {status === 'COMPLETED' && (
              <span className="badge badge-success" style={{ fontSize: '0.85rem', padding: '0.5rem 1rem' }}>
                <CheckCircle2 size={16} /> Rescue Successfully Completed
              </span>
            )}
          </div>
        </div>

        {/* AI Reasoning & Rationale Card */}
        <div style={{ background: 'rgba(15, 23, 42, 0.6)', padding: '1.25rem', borderRadius: '0.75rem', border: '1px solid var(--border-color)', marginBottom: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
            <Sparkles size={16} color="#34d399" />
            <span style={{ fontSize: '0.8rem', fontWeight: 700, color: '#34d399', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
              AI Agent Rationale & Root Cause Analysis
            </span>
          </div>
          <p style={{ fontSize: '0.875rem', color: '#f8fafc', marginBottom: '0.5rem', lineHeight: '1.5' }}>
            {plan.summary_rationale}
          </p>
          <p style={{ fontSize: '0.8rem', color: '#94a3b8' }}>
            <strong>Analysis:</strong> {plan.root_cause_analysis}
          </p>
        </div>

        {/* Forecasted Metrics Bar */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '1rem', paddingTop: '0.75rem', borderTop: '1px solid var(--border-color)' }}>
          <div>
            <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Estimated Cost</span>
            <div style={{ fontSize: '1.1rem', fontWeight: 700, color: '#f8fafc' }}>
              ${plan.estimated_cost_usd.toFixed(2)}
            </div>
          </div>
          <div>
            <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Estimated Food Saved</span>
            <div style={{ fontSize: '1.1rem', fontWeight: 700, color: '#34d399' }}>
              {plan.estimated_food_saved_kg} kg (~{Math.round(plan.estimated_food_saved_kg * 2.2)} meals)
            </div>
          </div>
          <div>
            <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Estimated CO₂e Averted</span>
            <div style={{ fontSize: '1.1rem', fontWeight: 700, color: '#818cf8' }}>
              {plan.estimated_co2_averted_kg} kg CO₂e
            </div>
          </div>
          <div>
            <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Step Progress</span>
            <div style={{ fontSize: '1.1rem', fontWeight: 700, color: '#f8fafc' }}>
              {current_step_index} / {plan.steps.length} Steps
            </div>
          </div>
        </div>
      </div>

      {/* Approval Alert Callout (If Awaiting Approval) */}
      {isAwaitingApproval && currentStep && (
        <div className="glass-panel pulse-amber" style={{ padding: '1.25rem', marginBottom: '1.5rem', background: 'rgba(245, 158, 11, 0.1)', border: '1px solid rgba(245, 158, 11, 0.4)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              <div style={{ padding: '0.5rem', borderRadius: '0.5rem', background: 'rgba(245, 158, 11, 0.2)', color: '#fbbf24' }}>
                <ShieldAlert size={24} />
              </div>
              <div>
                <h4 style={{ fontSize: '1rem', fontWeight: 700, color: '#fbbf24' }}>
                  Human Approval Required for Consequential Action
                </h4>
                <p style={{ fontSize: '0.8rem', color: '#cbd5e1' }}>
                  The AI agent has reached step: <strong>{currentStep.title}</strong> ({currentStep.tool_name}). External logistics and contracts cannot proceed autonomously without sign-off.
                </p>
              </div>
            </div>
            <button
              className="btn-primary"
              style={{ background: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)', boxShadow: '0 4px 14px rgba(245, 158, 11, 0.4)' }}
              onClick={() => onOpenApprovalModal(currentStep)}
            >
              Open Approval Gate &rarr;
            </button>
          </div>
        </div>
      )}

      {/* 7-Step Plan Stepper / DAG */}
      <div className="glass-panel" style={{ padding: '1.5rem' }}>
        <h3 style={{ fontSize: '1.1rem', fontWeight: 700, color: '#f8fafc', marginBottom: '1rem' }}>
          Step-by-Step Autonomous Action DAG
        </h3>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {plan.steps.map((step, index) => {
            const isCurrent = index === current_step_index && status !== 'COMPLETED';
            return (
              <div
                key={step.step_id}
                className="glass-panel"
                style={{
                  padding: '1.25rem',
                  border: isCurrent
                    ? '1px solid #10b981'
                    : step.status === 'SUCCEEDED'
                    ? '1px solid rgba(16, 185, 129, 0.3)'
                    : undefined,
                  background: isCurrent
                    ? 'rgba(16, 185, 129, 0.08)'
                    : step.status === 'SUCCEEDED'
                    ? 'rgba(16, 185, 129, 0.04)'
                    : undefined
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.75rem', marginBottom: '0.5rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                    <div style={{
                      width: '28px',
                      height: '28px',
                      borderRadius: '50%',
                      background: step.status === 'SUCCEEDED' ? '#10b981' : isCurrent ? '#f59e0b' : 'rgba(255,255,255,0.1)',
                      color: step.status === 'SUCCEEDED' ? '#ffffff' : isCurrent ? '#1e293b' : '#94a3b8',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '0.8rem',
                      fontWeight: 800
                    }}>
                      {step.step_order}
                    </div>
                    <div>
                      <h4 style={{ fontSize: '0.95rem', fontWeight: 700, color: '#f8fafc' }}>
                        {step.title}
                      </h4>
                      <span style={{ fontSize: '0.75rem', color: '#94a3b8', fontFamily: 'monospace' }}>
                        tool: {step.tool_name}()
                      </span>
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    {getStepStatusBadge(step.status, step.sensitivity)}
                    {step.approval_required && (
                      <span className="badge badge-warning" style={{ fontSize: '0.65rem' }}>
                        <Lock size={10} /> Gate Action
                      </span>
                    )}
                  </div>
                </div>

                <p style={{ fontSize: '0.825rem', color: '#cbd5e1', marginBottom: '0.75rem', paddingLeft: '2.5rem' }}>
                  {step.description}
                </p>

                {/* Expected vs Actual Outcome */}
                <div style={{ paddingLeft: '2.5rem', display: 'flex', flexDirection: 'column', gap: '0.4rem', fontSize: '0.75rem' }}>
                  <div style={{ color: '#94a3b8' }}>
                    <strong style={{ color: '#cbd5e1' }}>Expected Outcome:</strong> {step.expected_outcome}
                  </div>
                  <div style={{ color: '#94a3b8' }}>
                    <strong style={{ color: '#cbd5e1' }}>Verification Rule:</strong> <code style={{ color: '#38bdf8' }}>{step.verification_rule}</code>
                  </div>

                  {step.actual_outcome && (
                    <div style={{ marginTop: '0.35rem', padding: '0.5rem 0.75rem', borderRadius: '0.5rem', background: 'rgba(0, 0, 0, 0.4)', border: '1px solid var(--border-color)', fontFamily: 'monospace', color: '#34d399' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.2rem', color: '#a7f3d0', fontWeight: 600 }}>
                        <ShieldCheck size={14} /> Post-Execution Mathematical Verification:
                      </div>
                      <div style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-all', fontSize: '0.7rem' }}>
                        {step.actual_outcome}
                      </div>
                    </div>
                  )}
                </div>

              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
