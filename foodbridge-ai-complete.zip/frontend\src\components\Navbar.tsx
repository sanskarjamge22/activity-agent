import React from 'react';
import { UserRole } from '../types';
import { 
  Sprout, 
  LayoutDashboard, 
  PlusCircle, 
  GitMerge, 
  ShieldAlert, 
  FileCheck, 
  ShieldCheck, 
  User, 
  Sparkles
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  pendingApprovalsCount: number;
  demoMode: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  userRole,
  setUserRole,
  pendingApprovalsCount,
  demoMode
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'create', label: 'Create Surplus Listing', icon: PlusCircle },
    { id: 'plan', label: 'AI Plan & Agent', icon: GitMerge },
    { 
      id: 'approvals', 
      label: 'Approval Gate', 
      icon: ShieldAlert, 
      badge: pendingApprovalsCount > 0 ? pendingApprovalsCount : undefined 
    },
    { id: 'audit', label: 'Audit Trail', icon: FileCheck },
    { id: 'settings', label: 'Security & Demo', icon: ShieldCheck }
  ];

  const roleLabels: Record<UserRole, { label: string; icon: string }> = {
    canteen_staff: { label: 'Canteen Staff (Donor)', icon: '🧑‍🍳' },
    dispatcher: { label: 'Logistics Dispatcher', icon: '🚚' },
    auditor: { label: 'Compliance Auditor', icon: '🔍' },
    admin: { label: 'System Admin', icon: '🛡️' }
  };

  return (
    <header className="glass-panel" style={{ borderRadius: '0 0 1.25rem 1.25rem', marginBottom: '1.5rem', padding: '1rem 1.75rem' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
        
        {/* Brand */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem', cursor: 'pointer' }} onClick={() => setActiveTab('dashboard')}>
          <div style={{
            background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
            padding: '0.65rem',
            borderRadius: '0.85rem',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 4px 12px rgba(16, 185, 129, 0.4)'
          }}>
            <Sprout size={26} color="#ffffff" />
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <h1 style={{ fontSize: '1.35rem', fontWeight: 800, letterSpacing: '-0.02em', background: 'linear-gradient(to right, #ffffff, #a7f3d0)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                FoodBridge AI
              </h1>
              <span className="badge badge-success" style={{ fontSize: '0.65rem', padding: '0.15rem 0.45rem' }}>
                Autonomous Agent
              </span>
            </div>
            <p style={{ fontSize: '0.75rem', color: '#94a3b8' }}>
              Smart Food Waste Rescue Agent • Restaurant & Canteen Redistribution
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', flexWrap: 'wrap' }}>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.45rem',
                  padding: '0.55rem 0.95rem',
                  borderRadius: '0.65rem',
                  fontSize: '0.825rem',
                  fontWeight: 600,
                  cursor: 'pointer',
                  border: isActive ? '1px solid rgba(16, 185, 129, 0.4)' : '1px solid transparent',
                  background: isActive ? 'rgba(16, 185, 129, 0.15)' : 'transparent',
                  color: isActive ? '#34d399' : '#cbd5e1',
                  transition: 'all 0.15s ease'
                }}
              >
                <Icon size={16} />
                <span>{item.label}</span>
                {item.badge !== undefined && (
                  <span style={{
                    background: '#f59e0b',
                    color: '#1e293b',
                    fontSize: '0.65rem',
                    fontWeight: 800,
                    padding: '0.1rem 0.4rem',
                    borderRadius: '999px',
                    marginLeft: '0.2rem'
                  }}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Active Role Switcher & Mode Pill */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          {demoMode && (
            <div className="badge badge-cyan" title="Running in deterministic demo mode with synthetic sensor telemetry">
              <Sparkles size={12} />
              <span>Demo Mode</span>
            </div>
          )}

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', background: 'rgba(255, 255, 255, 0.05)', padding: '0.35rem 0.65rem', borderRadius: '0.65rem', border: '1px solid rgba(255, 255, 255, 0.1)' }}>
            <User size={14} color="#94a3b8" />
            <select
              value={userRole}
              onChange={(e) => setUserRole(e.target.value as UserRole)}
              style={{
                background: 'transparent',
                border: 'none',
                color: '#f8fafc',
                fontSize: '0.75rem',
                fontWeight: 600,
                outline: 'none',
                cursor: 'pointer'
              }}
            >
              {(Object.keys(roleLabels) as UserRole[]).map((r) => (
                <option key={r} value={r} style={{ background: '#0f172a', color: '#f8fafc' }}>
                  {roleLabels[r].icon} {roleLabels[r].label}
                </option>
              ))}
            </select>
          </div>
        </div>

      </div>
    </header>
  );
};
