import time
from typing import Callable, Dict, Any, Optional
from pydantic import BaseModel
from app.models.schemas import ToolSensitivity, ToolCallRecord, StepStatus
from app.config import settings

class ToolDefinition(BaseModel):
    name: str
    description: str
    sensitivity: ToolSensitivity
    schema_params: Dict[str, Any]

class ToolRegistry:
    def __init__(self):
        self._tools: Dict[str, Callable] = {}
        self._definitions: Dict[str, ToolDefinition] = {}

    def register(
        self,
        name: str,
        description: str,
        sensitivity: ToolSensitivity,
        schema_params: Dict[str, Any]
    ):
        """Decorator to register a validated tool."""
        def decorator(func: Callable):
            self._tools[name] = func
            self._definitions[name] = ToolDefinition(
                name=name,
                description=description,
                sensitivity=sensitivity,
                schema_params=schema_params
            )
            return func
        return decorator

    def get_definitions(self) -> Dict[str, ToolDefinition]:
        return dict(self._definitions)

    def get_allowlist(self) -> set[str]:
        return set(self._tools.keys())

    def execute_tool(
        self,
        tool_name: str,
        arguments: Dict[str, Any]
    ) -> ToolCallRecord:
        """Executes a registered tool with argument validation, timing, and error handling."""
        start_time = time.time()
        
        if tool_name not in self._tools:
            return ToolCallRecord(
                tool_name=tool_name,
                arguments=arguments,
                status=StepStatus.FAILED,
                error_message=f"Unauthorized or unknown tool '{tool_name}'",
                execution_time_ms=(time.time() - start_time) * 1000
            )

        handler = self._tools[tool_name]
        try:
            # Execute with defensive exception capture
            output = handler(**arguments)
            elapsed = (time.time() - start_time) * 1000
            return ToolCallRecord(
                tool_name=tool_name,
                arguments=arguments,
                output=output,
                status=StepStatus.SUCCEEDED,
                execution_time_ms=round(elapsed, 2)
            )
        except Exception as ex:
            elapsed = (time.time() - start_time) * 1000
            return ToolCallRecord(
                tool_name=tool_name,
                arguments=arguments,
                status=StepStatus.FAILED,
                error_message=str(ex),
                execution_time_ms=round(elapsed, 2)
            )

# Global tool registry
tool_registry = ToolRegistry()
